from datasets import load_dataset
from evaluate import evaluator
from transformers import AutoModelForImageClassification, pipeline, AutoImageProcessor
import evaluate


class ConfiguredMetric:
    def __init__(self, metric, *metric_args, **metric_kwargs):
        self.metric = metric
        self.metric_args = metric_args
        self.metric_kwargs = metric_kwargs

    def add(self, *args, **kwargs):
        return self.metric.add(*args, **kwargs)

    def add_batch(self, *args, **kwargs):
        return self.metric.add_batch(*args, **kwargs)

    def compute(self, *args, **kwargs):
        return self.metric.compute(*args, *self.metric_args, **kwargs, **self.metric_kwargs)

    @property
    def name(self):
        return self.metric.name

    def _feature_names(self):
        return self.metric._feature_names()


is_binary = True

# Load the dataset from the hub
if is_binary:
    dataset = load_dataset("zxcej/AICE_binary_dataset", split="test")
else:
    dataset = load_dataset("zxcej/AICE_dataset", split="test")

# Load the model from the hub
if is_binary:
    model_id = "outputs_binary"
else:
    model_id = "outputs"

model = AutoModelForImageClassification.from_pretrained(model_id)
image_processor = AutoImageProcessor.from_pretrained(model_id)


pipe = pipeline("image-classification", model=model, image_processor=image_processor, device=0)

task_evaluator = evaluator("image-classification")

label_mapping = {
    "SMT": 0,
    "angiodysplasia": 1,
    "bleeding": 2,
    "diverticulum": 3,
    "erosion": 4,
    "erythema": 5,
    "foreign body": 6,
    "lymph follicle": 7,
    "lymphangiectasia": 8,
    "no_class": 9,
    "polyp-like": 10,
    "stenosis": 11,
}

label_mapping_binary = {
    "Healthy": 1,
    "Disease": 0,
}


if is_binary:
    metric = evaluate.combine(["accuracy", "f1", "recall","precision"])
    lm = label_mapping_binary
else:
    metric = evaluate.combine([evaluate.load("accuracy"), ConfiguredMetric(evaluate.load("f1"), average="weighted"), ConfiguredMetric(evaluate.load("recall"), average="weighted")])
    lm = label_mapping

eval_results = task_evaluator.compute(
    model_or_pipeline=pipe,
    data=dataset,
    metric=metric,
    label_mapping= lm,
    device=0,
)
print ("Results:")
print(eval_results)


