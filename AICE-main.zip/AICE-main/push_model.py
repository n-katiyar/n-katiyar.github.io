from transformers import AutoConfig, AutoModelForImageClassification, AutoImageProcessor

model = AutoModelForImageClassification.from_pretrained("outputs_binary")
model.push_to_hub("AICE_model_binary")