# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import os
import shutil
import pandas as pd
from tqdm import tqdm


def move_dataset(csv_path, src_dic, dst_dic):
    df = pd.read_csv(csv_path)
    for index, row in tqdm(df.iterrows(), total=df.shape[0]):
        if pd.isna(row['image_number']):
            continue
        file_name = 'image{:05d}.jpg'.format(int(row['image_number']))
        class_name = None
        for col in row.index[2:-2]:
            if row[col] != 0:
                class_name = col
                break

        src_file = os.path.join(src_dic, file_name)
        if class_name:
            dst_folder = os.path.join(dst_dic, 'Disease')
            #dst_folder = os.path.join(dst_dic, class_name)
        else:
            dst_folder = os.path.join(dst_dic, 'Healthy')

        os.makedirs(dst_folder, exist_ok=True)
        shutil.copy(src_file, os.path.join(dst_folder, file_name))


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    cwd = os.getcwd()
    csv = os.path.join(cwd, 'AICE','all_annotation.csv')
    src = os.path.join(cwd, 'AICE','AICE_project_all_images','AICE_project_all_images')
    dst = os.path.join(cwd, 'binary_dataset')
    os.makedirs(dst, exist_ok=True)
    move_dataset(csv, src, dst)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
