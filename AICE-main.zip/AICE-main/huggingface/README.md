# Training
Training can be done using
```
python run_image_classification.py \
    --train_dir <path-to-train-root> \
    --output_dir ./outputs/ \
    --remove_unused_columns False \
    --do_train \
    --do_eval
    --train_val_split 0.2 \
```

Model can be chosen with the correct path from https://huggingface.co/docs/transformers/main/en/model_doc/auto#transformers.AutoModelForImageClassification (including ViT and ConvNeXT) by adding
```
--model_name_or_path <path-to-model>
``` 

## Dataset
dataset should follow 
```
root/dog/xxx.png
root/dog/xxy.png
root/dog/[...]/xxz.png

root/cat/123.png
root/cat/nsdf3.png
root/cat/[...]/asd932_.png
```
## Finetune
finetune.py is a script that exposes the training logic allowing far greater customization.
```
python3 finetune.py \
    --train_dir dataset \
    --output_dir ./outputs_finetune/ \
    --remove_unused_columns False \
    --train_val_split 0.2 \
    --per_device_train_batch_size 32 \

```

# Results
## Ksavir Dataset
| Model | Accuracy | Training Time |
| --- | --- | --- |
| vit-base-patch16-224-in21k | 0.99354 | 27m |
