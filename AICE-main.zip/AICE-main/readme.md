# Parse Dataset for AICE

This Python script moves a dataset of images from a source directory to a destination directory based on annotations provided in a CSV file. 
Images labeled as "Healthy" are moved to a folder called "Healthy", while images labeled with a specific disease are moved to a folder called "Disease" 
(Uncomment the other line to have the name of the subfolder corresponds to the name of the disease).

The script requires the following packages to be installed:
- os
- shutil
- pandas
- tqdm

## Usage

Before running the script, update the following variables to point to the correct paths:

- `csv_path`: the path to the CSV file containing the annotations
- `src_dic`: the path to the directory containing the images
- `dst_dic`: the path to the directory where the images will be moved to

Then, run the script in the command line or in an IDE.

```angular2html
python main.py 
```

