from datasets import load_dataset

ds= load_dataset('binary_dataset', split='train').train_test_split(test_size=0.2)

ds.push_to_hub('zxcej/AICE_binary_dataset')