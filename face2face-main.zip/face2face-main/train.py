from pathlib import Path
import os
import logging
import datasets
import diffusers
import transformers
import torch
import itertools
import tqdm
import math
import torch.nn.functional as F
from accelerate import Accelerator
from accelerate.utils import set_seed
from transformers import AutoTokenizer
from transformers import CLIPTextModel
from diffusers import AutoencoderKL, DDIMScheduler, DiffusionPipeline, UNet2DConditionModel
from diffusers.utils.import_utils import is_xformers_available
from diffusers.optimization import get_scheduler
from accelerate.logging import get_logger
from huggingface_hub import Repository, create_repo

from dataset import Img2ImgDataset, collate_fn
from utils import get_full_repo_name

#HYPERPARRAMETERS ================================================
gradient_accumulation_steps = 1
seed=42
gradient_checkpointing = False
allow_tf32 = True
scale_lr = True

resolution=512
center_crop = True
class_prompt = None
class_data_dir = None
instance_prompt = None
instance_data_dir = None

learning_rate = 5e-6
lr_scheduler = "constant"
lr_warmup_steps = 5000
lr_num_cycles = 1
lr_power = 1.0

train_batch_size = 1
adam_beta1 = 0.9
adam_beta2 = 0.999
adam_epsilon = 1e-8
adam_weight_decay = 0.01
train_text_encoder = False
num_train_epochs = 1
resume_from_checkpoint = None
max_train_steps = None
dataloader_num_workers = 0
mixed_precision = None
with_prior_preservation = False
prior_loss_weight = 1.0
checkpointing_steps = 5000
# Can save memory when set to true
set_grads_to_none = False
max_grad_norm = 1.0

hub_model_id = None
hub_token = None
push_to_hub = False

logging_dir = "logs"
output_dir = "output"
report_to = "tensorboard"

Configs = { "learning_rate":learning_rate,
            "lr_scheduler":lr_scheduler,
            "lr_warmup_steps":lr_warmup_steps,
            "lr_num_cycles":lr_num_cycles,
            "lr_power":lr_power,
            "train_batch_size":train_batch_size,
            "adam_beta1":adam_beta1,
            "adam_beta2":adam_beta2,
            "adam_epsilon":adam_epsilon,
            "adam_weight_decay":adam_weight_decay,
            "train_text_encoder":train_text_encoder,
            "num_train_epochs":num_train_epochs,
            "resume_from_checkpoint":resume_from_checkpoint,
            "max_train_steps":max_train_steps,
            "dataloader_num_workers":dataloader_num_workers,
            "mixed_precision":mixed_precision,
            "with_prior_preservation":with_prior_preservation,
            "prior_loss_weight":prior_loss_weight,
            "checkpointing_steps":checkpointing_steps,
            "set_grads_to_none":set_grads_to_none,
            "max_grad_norm":max_grad_norm,
            "hub_model_id":hub_model_id,
            "hub_token":hub_token,
            "push_to_hub":push_to_hub,
            "logging_dir":logging_dir,
            "output_dir":output_dir,
            "report_to":report_to,
            "gradient_accumulation_steps":gradient_accumulation_steps,
            "seed":seed,
            "gradient_checkpointing":gradient_checkpointing,
            "allow_tf32":allow_tf32,
            "scale_lr":scale_lr,
            "resolution":resolution,
            "center_crop":center_crop,
            "class_prompt":class_prompt,
            "class_data_dir":class_data_dir,
            "instance_prompt":instance_prompt,
            "instance_data_dir":instance_data_dir,
}

# MODEL================================================================
# tokenizer_name_cycle_diffusion = 'openai/clip-vit-large-patch14' # NOTE: out of scope for commercial use
model_path_cycle_diffusion = 'CompVis/stable-diffusion-v1-4'

model_path = model_path_cycle_diffusion

# SETUP================================================================
logger = get_logger(__name__)
logging_dir = Path(output_dir, logging_dir)

accelerator = Accelerator(
    gradient_accumulation_steps=gradient_accumulation_steps,
    mixed_precision=mixed_precision,
    log_with=report_to,
    logging_dir=logging_dir,
)

 # Make one log on every process with the configuration for debugging.
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger.info(accelerator.state, main_process_only=False)
datasets.utils.logging.set_verbosity_warning()
transformers.utils.logging.set_verbosity_warning()
diffusers.utils.logging.set_verbosity_info()

set_seed(seed)

# Handle the repository creation
if accelerator.is_main_process:
    if push_to_hub:
        if hub_model_id is None:
            repo_name = get_full_repo_name(Path(output_dir).name, token=hub_token)
        else:
            repo_name = hub_model_id
        create_repo(repo_name, exist_ok=True, token=hub_token)
        repo = Repository(output_dir, clone_from=repo_name, token=hub_token)

        with open(os.path.join(output_dir, ".gitignore"), "w+") as gitignore:
            if "step_*" not in gitignore:
                gitignore.write("step_*\n")
            if "epoch_*" not in gitignore:
                gitignore.write("epoch_*\n")
    elif output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)

tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            subfolder="tokenizer",
            use_fast=False,
        )

# import correct text encoder class
# text_encoder_cls = CLIPTextModel(model_path, None)

# Load scheduler and models
noise_scheduler = DDIMScheduler.from_pretrained(model_path, subfolder="scheduler")
text_encoder = CLIPTextModel.from_pretrained(model_path, subfolder="text_encoder")
vae = AutoencoderKL.from_pretrained(model_path, subfolder="vae")
unet = UNet2DConditionModel.from_pretrained(model_path, subfolder="unet")

# What to train TODO: train text encoder?
vae.requires_grad_(False)

if is_xformers_available():
    unet.enable_xformers_memory_efficient_attention()
else:
    logger.warning(
        "xformers is not installed, falling back to standard attention. "
        "Install xformers to use memory-efficient attention."
    )

# Enable to lower memory usage at the cost of speed
if gradient_checkpointing:
        unet.enable_gradient_checkpointing()
        if train_text_encoder:
            text_encoder.gradient_checkpointing_enable()

# Check that all trainable models are in full precision
low_precision_error_string = (
    "Please make sure to always have all model weights in full float32 precision when starting training - even if"
    " doing mixed precision training. copy of the weights should still be float32."
)

if accelerator.unwrap_model(unet).dtype != torch.float32:
    raise ValueError(
        f"Unet loaded as datatype {accelerator.unwrap_model(unet).dtype}. {low_precision_error_string}"
    )

if train_text_encoder and accelerator.unwrap_model(text_encoder).dtype != torch.float32:
    raise ValueError(
        f"Text encoder loaded as datatype {accelerator.unwrap_model(text_encoder).dtype}."
        f" {low_precision_error_string}"
    )

# Enable TF32 for faster training on Ampere GPUs,
# cf https://pytorch.org/docs/stable/notes/cuda.html#tensorfloat-32-tf32-on-ampere-devices
if allow_tf32:
    torch.backends.cuda.matmul.allow_tf32 = True

if scale_lr:
    learning_rate = (
        learning_rate * gradient_accumulation_steps * train_batch_size * accelerator.num_processes
    )
optimizer_class = torch.optim.AdamW

# Optimizer creation
params_to_optimize = (
    itertools.chain(unet.parameters(), text_encoder.parameters()) if train_text_encoder else unet.parameters()
)
optimizer = optimizer_class(
    params_to_optimize,
    lr=learning_rate,
    betas=(adam_beta1, adam_beta2),
    weight_decay=adam_weight_decay,
    eps=adam_epsilon,
)

# Dataset and DataLoaders creation:
train_dataset = Img2ImgDataset(
    instance_data_root=instance_data_dir,
    instance_prompt=instance_prompt,
    class_data_root=class_data_dir if with_prior_preservation else None,
    class_prompt=class_prompt,
    tokenizer=tokenizer,
    size=resolution,
    center_crop=center_crop,
)

train_dataloader = torch.utils.data.DataLoader(
    train_dataset,
    batch_size=train_batch_size,
    shuffle=True,
    collate_fn=lambda examples: collate_fn(examples, with_prior_preservation),
    num_workers=dataloader_num_workers,
)

# Scheduler and math around the number of training steps.
overrode_max_train_steps = False
num_update_steps_per_epoch = math.ceil(len(train_dataloader) / gradient_accumulation_steps)
if max_train_steps is None:
    max_train_steps = num_train_epochs * num_update_steps_per_epoch
    overrode_max_train_steps = True

lr_scheduler = get_scheduler(
    lr_scheduler,
    optimizer=optimizer,
    num_warmup_steps=lr_warmup_steps * gradient_accumulation_steps,
    num_training_steps=max_train_steps * gradient_accumulation_steps,
    num_cycles=lr_num_cycles,
    power=lr_power,
)

# Prepare everything with our `accelerator`.
if train_text_encoder:
    unet, text_encoder, optimizer, train_dataloader, lr_scheduler = accelerator.prepare(
        unet, text_encoder, optimizer, train_dataloader, lr_scheduler
    )
else:
    unet, optimizer, train_dataloader, lr_scheduler = accelerator.prepare(
        unet, optimizer, train_dataloader, lr_scheduler
    )

# For mixed precision training we cast the text_encoder and vae weights to half-precision
# as these models are only used for inference, keeping weights in full precision is not required.
weight_dtype = torch.float32
if accelerator.mixed_precision == "fp16":
    weight_dtype = torch.float16
elif accelerator.mixed_precision == "bf16":
    weight_dtype = torch.bfloat16

# Move vae and text_encoder to device and cast to weight_dtype
vae.to(accelerator.device, dtype=weight_dtype)

if not train_text_encoder:
    text_encoder.to(accelerator.device, dtype=weight_dtype)

# We need to recalculate our total training steps as the size of the training dataloader may have changed.
num_update_steps_per_epoch = math.ceil(len(train_dataloader) / gradient_accumulation_steps)
if overrode_max_train_steps:
    max_train_steps = num_train_epochs * num_update_steps_per_epoch
# Afterwards we recalculate our number of training epochs
num_train_epochs = math.ceil(max_train_steps / num_update_steps_per_epoch)

# We need to initialize the trackers we use, and also store our configuration.
# The trackers initializes automatically on the main process.
if accelerator.is_main_process:
    accelerator.init_trackers("cyclediffusion", config=vars(Configs))

# Train!
total_batch_size = train_batch_size * accelerator.num_processes * gradient_accumulation_steps

logger.info("***** Running training *****")
logger.info(f"  Num examples = {len(train_dataset)}")
logger.info(f"  Num batches each epoch = {len(train_dataloader)}")
logger.info(f"  Num Epochs = {num_train_epochs}")
logger.info(f"  Instantaneous batch size per device = {train_batch_size}")
logger.info(f"  Total train batch size (w. parallel, distributed & accumulation) = {total_batch_size}")
logger.info(f"  Gradient Accumulation steps = {gradient_accumulation_steps}")
logger.info(f"  Total optimization steps = {max_train_steps}")
global_step = 0
first_epoch = 0

# Potentially load in the weights and states from a previous save
if resume_from_checkpoint:
    if resume_from_checkpoint != "latest":
        path = os.path.basename(resume_from_checkpoint)
    else:
        # Get the mos recent checkpoint
        dirs = os.listdir(output_dir)
        dirs = [d for d in dirs if d.startswith("checkpoint")]
        dirs = sorted(dirs, key=lambda x: int(x.split("-")[1]))
        path = dirs[-1] if len(dirs) > 0 else None

    if path is None:
        accelerator.print(
            f"Checkpoint '{resume_from_checkpoint}' does not exist. Starting a new training run."
        )
        resume_from_checkpoint = None
    else:
        accelerator.print(f"Resuming from checkpoint {path}")
        accelerator.load_state(os.path.join(output_dir, path))
        global_step = int(path.split("-")[1])

        resume_global_step = global_step * gradient_accumulation_steps
        first_epoch = global_step // num_update_steps_per_epoch
        resume_step = resume_global_step % (num_update_steps_per_epoch * gradient_accumulation_steps)

 # Only show the progress bar once on each machine.
progress_bar = tqdm(range(global_step, max_train_steps), disable=not accelerator.is_local_main_process)
progress_bar.set_description("Steps")

for epoch in range(first_epoch, num_train_epochs):
    unet.train()
    if train_text_encoder:
        text_encoder.train()
    for step, batch in enumerate(train_dataloader):
        # Skip steps until we reach the resumed step
        if resume_from_checkpoint and epoch == first_epoch and step < resume_step:
            if step % gradient_accumulation_steps == 0:
                progress_bar.update(1)
            continue

        with accelerator.accumulate(unet):
            # Convert images to latent space
            latents = vae.encode(batch["pixel_values"].to(dtype=weight_dtype)).latent_dist.sample()
            latents = latents * vae.config.scaling_factor

            # Sample noise that we'll add to the latents
            noise = torch.randn_like(latents)
            bsz = latents.shape[0]
            # Sample a random timestep for each image
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps, (bsz,), device=latents.device)
            timesteps = timesteps.long()

            # Add noise to the latents according to the noise magnitude at each timestep
            # (this is the forward diffusion process)
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            # Get the text embedding for conditioning
            encoder_hidden_states = text_encoder(batch["input_ids"])[0]

            # Predict the noise residual
            model_pred = unet(noisy_latents, timesteps, encoder_hidden_states).sample

            # Get the target for loss depending on the prediction type
            if noise_scheduler.config.prediction_type == "epsilon":
                target = noise
            elif noise_scheduler.config.prediction_type == "v_prediction":
                target = noise_scheduler.get_velocity(latents, noise, timesteps)
            else:
                raise ValueError(f"Unknown prediction type {noise_scheduler.config.prediction_type}")

            if with_prior_preservation:
                # Chunk the noise and model_pred into two parts and compute the loss on each part separately.
                model_pred, model_pred_prior = torch.chunk(model_pred, 2, dim=0)
                target, target_prior = torch.chunk(target, 2, dim=0)

                # Compute instance loss
                loss = F.mse_loss(model_pred.float(), target.float(), reduction="mean")

                # Compute prior loss
                prior_loss = F.mse_loss(model_pred_prior.float(), target_prior.float(), reduction="mean")

                # Add the prior loss to the instance loss.
                loss = loss + prior_loss_weight * prior_loss
            else:
                loss = F.mse_loss(model_pred.float(), target.float(), reduction="mean")

            accelerator.backward(loss)
            if accelerator.sync_gradients:
                params_to_clip = (
                    itertools.chain(unet.parameters(), text_encoder.parameters())
                    if train_text_encoder
                    else unet.parameters()
                )
                accelerator.clip_grad_norm_(params_to_clip, max_grad_norm)
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad(set_to_none=set_grads_to_none)

        # Checks if the accelerator has performed an optimization step behind the scenes
        if accelerator.sync_gradients:
            progress_bar.update(1)
            global_step += 1

            if global_step % checkpointing_steps == 0:
                if accelerator.is_main_process:
                    save_path = os.path.join(output_dir, f"checkpoint-{global_step}")
                    accelerator.save_state(save_path)
                    logger.info(f"Saved state to {save_path}")

        logs = {"loss": loss.detach().item(), "lr": lr_scheduler.get_last_lr()[0]}
        progress_bar.set_postfix(**logs)
        accelerator.log(logs, step=global_step)

        if global_step >= max_train_steps:
            break

# Create the pipeline using using the trained modules and save it.
accelerator.wait_for_everyone()
if accelerator.is_main_process:
    pipeline = DiffusionPipeline.from_pretrained(
        model_path,
        unet=accelerator.unwrap_model(unet),
        text_encoder=accelerator.unwrap_model(text_encoder),
    )
    pipeline.save_pretrained(output_dir)

    if push_to_hub:
        repo.push_to_hub(commit_message="End of training", blocking=False, auto_lfs_prune=True)

accelerator.end_training()