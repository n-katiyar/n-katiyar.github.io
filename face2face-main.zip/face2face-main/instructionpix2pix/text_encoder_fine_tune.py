from transformers import T5Tokenizer, T5ForConditionalGeneration
from transformers import get_scheduler
from tqdm.auto import tqdm
from dataset import get_text_dataset, PromptDataset
from torch.optim import AdamW
from accelerate import Accelerator
import torch
torch.backends.cuda.matmul.allow_tf32 = True
accelerator = Accelerator(mixed_precision='bf16')

tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-large",torch_dtype=torch.bfloat16)
model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-large",torch_dtype=torch.bfloat16).to("cuda")

# the following 2 hyperparameters are task-specific
max_source_length = 128
max_target_length = 128
num_epochs = 20
device = 'cuda'
optimizer = AdamW(model.parameters(), lr=1e-5)
batch_size=8


inputs, outputs = get_text_dataset()
prompt_dataset = PromptDataset(inputs, outputs)
train_size = int(0.8 * len(prompt_dataset))
test_size = len(prompt_dataset) - train_size
train_dataset, test_dataset = torch.utils.data.random_split(prompt_dataset, [train_size, test_size])
num_training_steps = int(num_epochs * len(train_dataset) / batch_size)
num_val_steps = int(len(test_dataset) / batch_size)
train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=True)
lr_scheduler = get_scheduler(
    name="linear", optimizer=optimizer, num_warmup_steps=0, num_training_steps=num_training_steps
)
min_test_loss = 2000
progress_bar = tqdm(range(num_training_steps))
for epoch in range(num_epochs):
    model.train()
    for batch in train_dataloader: 
        
        inputs, outputs = batch
        encoding = tokenizer(
            inputs,
            padding="longest",
            max_length=max_source_length,
            truncation=True,
            return_tensors="pt",
        )
        input_ids, attention_mask = encoding.input_ids, encoding.attention_mask
        target_encoding = tokenizer(
            outputs,
            padding="longest",
            max_length=max_target_length,
            truncation=True,
            return_tensors="pt",
        )
        labels = target_encoding.input_ids
        labels[labels == tokenizer.pad_token_id] = -100
        outputs = model(input_ids=input_ids.to("cuda"),attention_mask=attention_mask.to("cuda"), labels=labels.to("cuda"))
        loss = outputs.loss
        loss.backward()

        optimizer.step()
        lr_scheduler.step()
        optimizer.zero_grad()
        progress_bar.update(1)
        progress_bar.set_postfix({"train_loss": loss.item()})

    progress_bar2 = tqdm(range(num_val_steps))
    model.eval()
    with torch.no_grad():
        test_loss = 0
        for batch in test_dataloader: 
            inputs, outputs = batch
            encoding = tokenizer(
                inputs,
                padding="longest",
                max_length=max_source_length,
                truncation=True,
                return_tensors="pt",
            )
            input_ids, attention_mask = encoding.input_ids, encoding.attention_mask
            target_encoding = tokenizer(
                outputs,
                padding="longest",
                max_length=max_target_length,
                truncation=True,
                return_tensors="pt",
            )
            labels = target_encoding.input_ids
            labels[labels == tokenizer.pad_token_id] = -100
            outputs = model(input_ids=input_ids.to("cuda"),attention_mask=attention_mask.to("cuda"), labels=labels.to("cuda"))
            test_loss += outputs.loss

            progress_bar2.update(1)
            # progress_bar2.set_postfix({"val_loss": loss.item()})
        print("epoch", epoch, "test_loss", test_loss/num_val_steps)
        if test_loss/num_val_steps < min_test_loss:
            min_test_loss = test_loss
            print("saving model")
            model.save_pretrained("flan-t5-large-finetuned")


print("training done")


