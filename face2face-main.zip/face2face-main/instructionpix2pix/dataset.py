import json
import torch
DELIMITER_0 = "\n##\n"
DELIMITER_1 = "\n%%\n"
STOP = "\nEND"

def get_text_dataset(path='human-written-prompts.jsonl'):
    # open the file containing the training examples
    with open(path, "r") as f:
        # load the file line-by-line as a list of json objects
        examples = [json.loads(line) for line in f.readlines()]

    input_sequences = [example["input"]+DELIMITER_0 for example in examples]
    output_sequences = [example["edit"] + DELIMITER_1 + example["output"] + STOP for example in examples]

    return input_sequences, output_sequences

class PromptDataset(torch.utils.data.Dataset):
    def __init__(self, input,outputs):
        self.input = input
        self.outputs = outputs

    def __getitem__(self, idx):
        return self.input[idx], self.outputs[idx]

    def __len__(self):
        return len(self.input)