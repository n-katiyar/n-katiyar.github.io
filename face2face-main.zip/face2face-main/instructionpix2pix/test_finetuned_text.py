from transformers import T5Tokenizer, T5ForConditionalGeneration
from dataset import DELIMITER_0, DELIMITER_1, STOP

tokenizer = T5Tokenizer.from_pretrained("google/t5-v1_1-large")
model = T5ForConditionalGeneration.from_pretrained("./t5-3b-finetuned/").to("cuda")

input_ids = tokenizer("a photo of a women"+DELIMITER_0, return_tensors="pt").input_ids.to("cuda")
# print(input_ids)
outputs = model.generate(input_ids)
# print(outputs)

print(tokenizer.decode(outputs[0]))