import PIL
import requests
import json
from clip_interrogator import Config, Interrogator
# clip_model_name = "ViT-L-14/openai"
clip_model_name = "ViT-H-14/laion2b_s32b_b79k"
# url2 = "https://media.glamour.com/photos/5a425fd3b6bcee68da9f86f8/1:1/w_741,h_741,c_limit/best-face-oil.png"


def download_image(url):
    image = PIL.Image.open(requests.get(url, stream=True).raw)
    image = PIL.ImageOps.exif_transpose(image)
    image = image.convert("RGB")
    return image

# open scrapped data jsonl file
urls = []
i = 0
with open('scrapped_data.jsonl', 'r') as f:
    for line in f:
        json_line = json.loads(line)
        if "before" in json_line['content']:
            # print(json_line['content'])
            urls.append('https:'+json_line['content'])

ci = Interrogator(Config(clip_model_name=clip_model_name))
with open('prompts.jsonl', 'w') as f:
    for url in urls:
        image = download_image(url)
        prompt = ci.interrogate(image,max_flavors=3,min_flavors=1) 
        f.write("{\"input\": \""+prompt + "\", \"edit\": \"\", \"output\": \"\"}\n")