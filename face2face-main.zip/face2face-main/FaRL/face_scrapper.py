import re
from urllib.request import urlopen
import urllib
from bs4 import BeautifulSoup
import json
import time
import PIL
from PIL import Image
import requests
import random
# from clip_interrogator import Config, Interrogator
from transformers import Blip2Processor, Blip2ForConditionalGeneration
import torch
clip_model_name = "ViT-L-14/openai"
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

processor = Blip2Processor.from_pretrained("Salesforce/blip2-flan-t5-xl")
model = Blip2ForConditionalGeneration.from_pretrained(
    "Salesforce/blip2-flan-t5-xl", torch_dtype=torch.float16
)
model.to(device)


def download_image(url):
    image = PIL.Image.open(requests.get(url, stream=True).raw)
    # image = PIL.ImageOps.exif_transpose(image)
    # image = image.convert("RGB")
    return image


user_agent = ['Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1',
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246',
              'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36']
headers={'User-Agent':user_agent,} 
domain_url = 'https://www.realself.com'
botox_url = domain_url + '/photos/botox'
page_urls = []
category = []

# # botox
# for i in range(1,20):
#     page_urls.append(f'https://www.realself.com/photo/galleryFilter?bypass_cache=false&page={i}&search_type=recommended&topic_id=25')
#     category.append('botox')

# # facelift
# for i in range(1,20):
#     page_urls.append(f"https://www.realself.com/photo/galleryFilter?bypass_cache=false&page={i}&search_type=recommended&topic_id=168")
#     category.append('facelift')

# # dermal fillers
# for i in range(1,20):
#     page_urls.append(f"https://www.realself.com/photo/galleryFilter?bypass_cache=false&page={i}&search_type=recommended&topic_id=106611")
#     category.append('dermal fillers')

# # lip fillers

# rhinoplasty
# NOTE:last done was 58
for i in range(59,200):
    page_urls.append(f"https://www.realself.com/photo/galleryFilter?bypass_cache=false&page={i}&search_type=recommended&topic_id=187")
    category.append('rhinoplasty')

# ci = Interrogator(Config(clip_model_name=clip_model_name))

for i in range(len(page_urls)):   
    # break 
    headers = {'User-Agent': user_agent[random.randint(0,2)],}
    request=urllib.request.Request(page_urls[i],None,headers, ) #The assembled request
    response = urllib.request.urlopen(request).read()
    soup = BeautifulSoup(response, 'html.parser')
    # print(soup.prettify())
    html = json.loads(soup.prettify())['html']
    html_soup = BeautifulSoup(html, 'html.parser')
    # print(html_soup)
    # open a jsonl file
    with open('scrapped-data/rs_various-v3.jsonl', 'a') as f:
        # get all text inside <rs-image> tags
        for img in html_soup.find_all('rs-image'):
            # get the content
            content = img.get('content')
            alt = img.get('alt')
            image = download_image('https:' + content)
            # prompt = ci.interrogate(image,max_flavors=0,min_flavors=0)
            prompt = "Question: describe the person's nose from the point of view of a plastic surgeon. Answer:"
            inputs = processor(images=image, text=prompt, return_tensors="pt").to(device, torch.float16)

            generated_ids = model.generate(**inputs)
            prompt = processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()
            # print(prompt)

            inputs = processor(images=image, return_tensors="pt").to(device, torch.float16)
            generated_ids = model.generate(**inputs)
            caption = processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()
            print(f"Caption:{caption}, Prompt:{prompt}")
            if "before" in content:
                ba = "before"
            elif "after" in content:
                ba = "after"
            else:
                ba = "none"
            # only interest in before or after, not both
            if "before and after" not in prompt:
                f.write("{\"alt\": \""+ str(alt) + "\", \"ba\": \"" + ba + "\", \"content\": \"https:" + str(content) + "\", \"category\": \""+category[i]+"\", \"clip-prompt\": \"" + str(prompt) +"\"}\n")
    print(i)
