from diffusers import StableDiffusionPipeline, EulerDiscreteScheduler
from transformers import AutoTokenizer, CLIPTextModel, CLIPConfig
import torch

model_id = "CompVis/stable-diffusion-v1-4"
# model_id = "stabilityai/stable-diffusion-2-base"
model_path = "./output"

# Use the Euler scheduler here instead
# scheduler = EulerDiscreteScheduler.from_pretrained(model_id, subfolder="scheduler")
# text_encoder = CLIPTextModel.from_pretrained('openai/clip-vit-base-patch16')
# text_encoder.base_model = torch.load('../FaRL/FaRL-Base-Patch16-LAIONFace20M-ep16.pth')['state_dict']
pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16,revision='fp16',safety_checker=None)
pipe.unet.load_attn_procs(model_path)
pipe.to("cuda")

prompt = "a close up of a person, large nose, natural lighting"

for i in range(5):
    image = pipe(prompt,num_inference_steps=100).images[0]
        
    image.save(f"generated/generated_{i}.png")