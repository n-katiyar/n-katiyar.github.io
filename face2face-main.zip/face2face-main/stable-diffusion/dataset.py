import json
import PIL
import requests
import random
from PIL import Image

after_rhynoplasty_keywords = ['cute','perfect','small']
before_rhynoplasty_keywords = ['large','wide','broad','hump','bump','crooked','bulbous','deviated']
prompt_keyword = {'large':' large',
                  'wide':' wide',
                  'broad':' broad',
                  'hump':' humpy',
                  'bump':' bumpy',
                  'crooked':' crooked',
                  'bulbous':' bulbous',
                  'deviated':' deviated',}

def download_image(url):
    image = Image.open(requests.get(url, stream=True).raw)
    image = PIL.ImageOps.exif_transpose(image)
    image = image.convert("RGB")
    return image

def create_caption(json_line):
    caption = json_line['clip-prompt'].split(',')[0]+','
    if json_line['category'] == 'rhinoplasty':

        if json_line['ba'] == 'before':
            found_keyword = False
            for keyword in before_rhynoplasty_keywords:
                if keyword in json_line['alt']:
                    found_keyword = True
                    caption += prompt_keyword[keyword]
                    
            if not found_keyword:
                caption+=" large"

        elif json_line['ba'] == 'after':
            caption +=after_rhynoplasty_keywords[random.randint(0,2)]
        caption += ' nose'
    return caption
    
def write_dataset(path, lines_to_write, url_to_download):
    with open(path, 'w') as f:
        i=0
        
        for line in lines_to_write:
            print(i)
            try:
                image = download_image(url_to_download[i])
                image.save('dataset/'+json.loads(line)['file_name'])
                f.write(line)
            except:
                print(f'error with {url_to_download[i]}')
            i+=1

# Create a hugging face stable diffusion dataset https://huggingface.co/docs/datasets/v2.4.0/en/image_load#imagefolder-with-metadata
def create_hf_sd_dataset(read_path, write_path):
    lines_to_write = []
    url_to_download = []
    with open(read_path,'r') as f:
        for line in f:
            json_line = json.loads(line)
            caption = create_caption(json_line)
            file_name = json_line['content'].split('/')[-1]
            lines_to_write.append("{\"file_name\": \"" + file_name +"\", \"text\": \"" + caption + "\"}\n")
            url_to_download.append(json_line['content'])

    write_dataset(write_path, lines_to_write, url_to_download)

create_hf_sd_dataset('../FaRL/scrapped-data/rs_various-v2.jsonl', 'dataset/metadata.jsonl')
    