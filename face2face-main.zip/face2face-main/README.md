# face2face

## Architecture
### 1. Fine Tuning Stable Diffusion
By default, stable diffusion is not trained to be able to generate faces with accurate facial features such as "small nose" or "big nose" and "small lips" or "big lips".
To train it to do so, we can use a dataset of before and after iamges of plastic surgery procedure.

We use BLIP2 Q&A to generate the edit prompts and BLIP2 caption to generate the caption.


## 3. Generate or use dataset of pairs of before/after images from input and edited prompts
Generating images is incrediby slow because most of them are too low quality. Instead, we can use image inversion from an existing image.

## 4. Train InstructionPix2Pix
We now follow the instructionPix2Pix paper to train a model to generate edited images from an image-edit prompt pair using our fine-tuned text-to-image model and the prompt triplets.
This is the most expensive test, which costed about 200 A100 hours to train for the InstructionPix2Pix paper.

## Training
Use the following command to train a model
```
accelerate config
```
    

## Models

Palette https://dl.acm.org/doi/fullHtml/10.1145/3528233.3530757
InstructPix2Pix https://arxiv.org/abs/2211.09800
cycleDiffusion https://arxiv.org/pdf/2210.05559.pdf

## FaRL
FaRL has provided by https://github.com/FacePerceiver/FaRL is unable to distinguish between facial features such as small nose and big nose (probably because LAION-FACE doesn't have that kind of prompt).

## Cycle Diffusion
### Architecture
Uses CLIP encoder and UNET2DCondition for unpaired image-to-image translation

## 
uses GPT-3 and Stable Diffusion for paired image-to-image editing.
Training is done on 100% generated images and still generalizes to real images.

## InstructPix2Pix
Original training took 25.5 hours on 8 A100 GPUs with resolution 256x256 and batch size 1024.
### Text Fine-tuning Strategy
In the original paper, text pairs are generated from ~700 human-written instructions, where the prompt 
is provided and the human write an edit instruction and an edited caption. 
Thus, we need to write manually these triplets as fine-tuning for the text encoder so that
it can then generate a large amounts of pairs from existing image-caption pairs

In the paper, an example triplet is the caption "girl with horse at sunset". From this, a human
writes the edit instruction "change the background to a city" and the edited caption 
"girl with horse at sunset in front of city".

In our case, an example prompt is "girl starring at camera" with the manually written edit instruction
" make her nose smaller" and edited caption "girl with small nose starring at camera".

Text prompt used during fine-tuning is the input caption concatenated with the "\n##\n" as a separator token.
The text completion is a concatenation of the instruction and edited caption with "\n%%\n" as a separator token
in between the two and "\nEND" appended to the end as the stop token.

Original prompt can either be taken from LAION-face or from clip-generated text using FaceCLIP of an high-quality face dataset. TODO: which one is better?

### Image Fine-tuning Strategy
Image are generated from a conditional model that takes in an image and its associated prompt. 
For every edited caption, we generate an image pair before/after using stable diffusion with prompt-to-prompt.
Finally, we train to conditional model to generate the edited image from an image-edit prompt pair.

Similarity can be measured using FaceCLIP instead of vanilla CLIP.