from datasets import load_dataset, Features, ClassLabel

def upload_to_hub(dataset_name,dataset_path):
    # Load your dataset
    dataset = load_dataset(dataset_path)

    # Upload your dataset to the Hugging Face Hub
    dataset.push_to_hub(dataset_name)

def binarize_dataset(dataset_name,dataset_path, label_to_keep="Normal clean mucosa"):
    # Load your dataset
    dataset = load_dataset(dataset_path)

    # Map the labels of the train split to 0 and 1
    train_dataset = dataset["train"].map(lambda example: {"label": int(example["label"] == label_to_keep)})

    # Update the features of the train split
    train_dataset = train_dataset.cast(Features({
        "image": train_dataset.features["image"],
        "label": ClassLabel(names=["pathology", "normal"])
    }))


    print(train_dataset.features['label'].names)

    # Upload your dataset to the Hugging Face Hub
    dataset["train"] = train_dataset
    dataset.push_to_hub(dataset_name)