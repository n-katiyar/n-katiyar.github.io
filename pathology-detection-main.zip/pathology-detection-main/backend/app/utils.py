import uuid
import time

def generate_unique_filename(filename):
    # Generate a random 8-character string
    random_string = str(uuid.uuid4().hex)[:8]
    
    # Extract the file extension from the original filename
    file_extension = filename.split('.')[-1]
    
    # Get the current timestamp in milliseconds
    timestamp = str(int(time.time() * 1000))
    
    # Combine the timestamp, random string, and file extension to create the new filename
    new_filename = f"{timestamp}-{random_string}.{file_extension}"
    
    return new_filename