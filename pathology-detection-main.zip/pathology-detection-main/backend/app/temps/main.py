from flask import Flask
from flask import request
from flask import jsonify
from pipeline import predict,load_image_processing_pipeline,generate_json,answer_question,initialize_chat_pipeline
from flask_cors import CORS
import boto3
import json
import base64
import math
# open json file with credentials
with open('credentials/creds.json') as f:
    creds = json.load(f)

s3 = boto3.client('s3',
                  aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],
                  aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],
                  region_name=creds['AWS_REGION'])

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

# Define endpoint for uploading images
@app.route('/upload-image', methods=['POST'])
def upload_image():
    # Get file and patient ID from request
    file = request.files['image']
    patient_id = request.form['patient_id']
    
    # Generate filename with patient ID
    filename = f'{patient_id}-{file.filename}'
    print(filename)
    
    # Upload file to S3 with patient ID in filename
    s3.put_object(Bucket=creds['AWS_S3_BUCKET'], Key=filename, Body=file, ServerSideEncryption=creds['ENCRYPTION'])
    
    return jsonify({'message': 'File uploaded successfully!'})

# Define endpoint for retrieving images
@app.route('/get-image/<filename>', methods=['GET'])
def get_image(filename):
    # Download file from S3
    response = s3.get_object(Bucket=creds['AWS_S3_BUCKET'], Key=filename)
    file = response['Body'].read()
    
    return file, 200, {'Content-Type': 'image/jpeg'}

@app.route('/get-images/<patient_id>', methods=['GET'])
def get_images(patient_id):
    # List all objects in the S3 bucket with the given patient ID in the filename
    response = s3.list_objects_v2(Bucket=creds['AWS_S3_BUCKET'], Prefix=f"{patient_id}-")

    # Extract the filenames from the response
    filenames = [obj['Key'] for obj in response.get('Contents', [])]

    # Get the images for the current page (assuming 10 images per page)
    page = request.args.get('page', default=1, type=int)
    per_page = 10
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    page_filenames = filenames[start_idx:end_idx]

    # Download the images from S3
    images = []
    for filename in page_filenames:
        response = s3.get_object(Bucket=creds['AWS_S3_BUCKET'], Key=filename)
        image_bytes = response['Body'].read()
        images.append(base64.b64encode(image_bytes).decode('utf-8'))

    # Return the images and pagination metadata
    return jsonify({
        'images': images,
        'total': len(filenames),
        'per_page': per_page,
        'page': page,
        'pages': math.ceil(len(filenames) / per_page)
    })



# @app.route("/predict", methods=["POST"])
# def predict():
#     """ Expect a json object with a list of images.
#         object = {'images': [image1, image2, ...]}"""
#     json_data = request.get_json()
#     print(json_data)
#     predictions = predict(json_data,model,image_processor)
#     json_predictions = generate_json(predictions)
#     return jsonify(json_predictions)

# @app.route("/chat", methods=["POST"])
# def chat():
#     """ Expects a json object with a message. """
#     json_data = request.get_json()
#     print(json_data)
#     predictions = answer_question(chat_bot,json_data["message"])
#     print(predictions)
#     return jsonify({"message":predictions[0]["generated_text"]})


if __name__ == '__main__':
    # model,image_processor = load_image_processing_pipeline("model")
    # chat_bot = initialize_chat_pipeline()
    app.run(debug=True)