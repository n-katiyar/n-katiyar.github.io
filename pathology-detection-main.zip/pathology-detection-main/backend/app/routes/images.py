from flask import Blueprint, jsonify, request, abort
from ..database import db
from app.models.models import Image, Appointment, Diagnosis
import json
import boto3
from werkzeug.utils import secure_filename
from ..utils import generate_unique_filename
import io
import boto3
import asyncio
import io
import requests

bp = Blueprint('images', __name__)
with open('/home/ec2-user/pathology-detection/backend/app/models/s3_creds.json','r') as f:
    creds = json.load(f)
s3 = boto3.client('s3',
                  aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],
                  aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],
                  region_name=creds['AWS_REGION'])

@bp.route('/appointments/<int:appointment_id>/images', methods=['GET'])
def get_appointment_images(appointment_id):
    page = request.args.get('page', default=1, type=int)
    per_page = 10 # adjust to your preference
    images = Image.query.filter_by(appointment_id=appointment_id,processed=True).paginate(page=page, per_page=per_page)
    if not images.items:
        return jsonify({'error': 'No images found for this appointment.'}), 404
    return jsonify({
        'images': [image.to_dict() for image in images.items],
        'page': page,
        'total_pages': images.pages,
        'total_items': images.total,
        'has_prev': images.has_prev,
        'has_next': images.has_next,
        'prev_page': images.prev_num,
        'next_page': images.next_num
    }), 200

@bp.route('/upload_image', methods=['POST'])
async def upload_image():
    appointment_id = request.form.get('appointment_id')
    appointment = Appointment.query.filter_by(id=appointment_id).first()
    if appointment is None:
        return jsonify({'error': 'Invalid appointment ID'}), 400
    print(request.files.getlist('image'))
    for file in request.files.getlist('image'):
        print(file)
        if file is None:
            return jsonify({'error': 'No file uploaded'}), 400
        
        processed = False # Set processed and modified to False by default
        modified = False
        filename = secure_filename(file.filename)
        filename = generate_unique_filename(filename)
        # file.save(filename)
        s3.upload_fileobj(file, creds['AWS_S3_BUCKET'], filename)

        # # Create a new Image object and save to database
        image = Image(
            appointment_id=appointment_id,
            image_name=filename,
            processed=processed,
            modified=modified
        )
        db.session.add(image)
    db.session.commit()
    # process the images
    await process_images(appointment_id)

    return {'success': True}, 200

async def process_images(appointment_id):
    # Fetch all images from the database that belong to the appointment
    images = Image.query.filter_by(appointment_id=appointment_id,processed=False).all()
    tasks = []
    for image in images:
        task = asyncio.ensure_future(process_image(image))
        tasks.append(task)
    await asyncio.gather(*tasks)
    return jsonify({'count':len(images)})

async def process_image(image):
    # Convert the image to bytes
    response = requests.get(image.to_dict()['image_url'])
    
    image_bytes = io.BytesIO(response.content)
    # Get diagnosis
    sm_client = boto3.client("sagemaker-runtime",aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],region_name=creds['AWS_REGION'])
    sm_endpoint_name = "image-classification"
    sm_content_type = "image/jpeg"
    response = sm_client.invoke_endpoint(
        EndpointName=sm_endpoint_name,
        ContentType=sm_content_type,
        Body=image_bytes
    )
    response = json.loads(response['Body'].read().decode('utf-8'))
    new_diagnosis = Diagnosis()
    for item in response:
        label = label_id_to_diagnosis(item['label'])
        setattr(new_diagnosis, f'{label}_accuracy', item['score'])

    # Add the new diagnosis to the database
    db.session.add(new_diagnosis)
    db.session.flush()
    image.ai_diagnosis_id = new_diagnosis.id
    image.processed = True
    db.session.commit()

def label_id_to_diagnosis(label_id):
    return {
        'LABEL_0': 'ampulla_of_vater',
        'LABEL_1': 'angiectasia',
        'LABEL_2': 'blood_fresh',
        'LABEL_3': 'blood_hematin',
        'LABEL_4': 'erosion',
        'LABEL_5': 'erythema',
        'LABEL_6': 'foreign_body',
        'LABEL_7': 'ileocecal_valve',
        'LABEL_8': 'lymphangiectasia',
        'LABEL_9': 'normal_clean_mucosa',
        'LABEL_10': 'polyp',
        'LABEL_11': 'pylorus',
        'LABEL_12': 'reduced_mucosal_view',
        'LABEL_13': 'ulcer',
    }[label_id]
# Parse the response body
# response_body = response['Body'].read().decode('utf-8')
# response_json = json.loads(response_body)  

@bp.route('/images/<int:image_id>', methods=['PUT'])
def update_image(image_id):

    image = Image.query.get(image_id)
    if not image:
        return {'error': 'Image not found'}, 404
    
    # Check if a manual diagnosis exists
    if (image.modified == True):
        # get the diagnosis
        diagnosis = Diagnosis.query.get(image.modified_diagnosis_id)
        # Get new values from request body
        data = request.get_json()
        new_values = {}
        for key in Diagnosis.__table__.columns.keys():
            if key in data:
                new_values[key] = data[key]
         # Set new values to the diagnosis
        for key, value in new_values.items():
            setattr(diagnosis, key, value)
    else:
        # Update the image's modified diagnosis ID
        # Create a new diagnosis
        new_diagnosis = Diagnosis()
        new_diagnosis.ampulla_of_vater_accuracy=request.json.get('ampulla_of_vater_accuracy'),
        new_diagnosis.angiectasia_accuracy=request.json.get('angiectasia_accuracy'),
        new_diagnosis.blood_fresh_accuracy=request.json.get('blood_fresh_accuracy'),
        new_diagnosis.blood_hematin_accuracy=request.json.get('blood_hematin_accuracy'),
        new_diagnosis.erosion_accuracy=request.json.get('erosion_accuracy'),
        new_diagnosis.erythema_accuracy=request.json.get('erythema_accuracy'),
        new_diagnosis.foreign_body_accuracy=request.json.get('foreign_body_accuracy'),
        new_diagnosis.ileocecal_valve_accuracy=request.json.get('ileocecal_valve_accuracy'),
        new_diagnosis.lymphangiectasia_accuracy=request.json.get('lymphangiectasia_accuracy'),
        new_diagnosis.normal_clean_mucosa_accuracy=request.json.get('normal_clean_mucosa_accuracy'),
        new_diagnosis. polyp_accuracy=request.json.get('polyp_accuracy'),
        new_diagnosis.pylorus_accuracy=request.json.get('pylorus_accuracy'),
        new_diagnosis.reduced_mucosal_view_accuracy=request.json.get('reduced_mucosal_view_accuracy'),
        new_diagnosis.ulcer_accuracy=request.json.get('ulcer_accuracy')
        # Add the new diagnosis to the database
        db.session.add(new_diagnosis)
        db.session.flush()
        # Update the image's modified diagnosis ID
        image.modified_diagnosis_id = new_diagnosis.id
        image.modified = True
    
    db.session.commit()
    
    return {'success': True}

@bp.route('/images/<int:image_id>', methods=['DELETE'])
def delete_image(image_id):
    image = Image.query.get_or_404(image_id)

    # delete the image from S3
    s3.delete_object(Bucket=creds['AWS_S3_BUCKET'], Key=image.image_name)

    # delete the image from the database
    db.session.delete(image)
    db.session.commit()

    return '', 204