from flask import Blueprint, jsonify, request, abort
from app.models.models import Diagnosis
from ..database import db

bp = Blueprint('diagnosis', __name__)


@bp.route('/diagnoses/<int:diagnosis_id>', methods=['GET'])
def get_diagnosis(diagnosis_id):
    diagnosis = Diagnosis.query.get(diagnosis_id)
    if not diagnosis:
        return {'error': 'Diagnosis not found'}, 404

    return jsonify({
        'id': diagnosis.id,
        'ampulla_of_vater_accuracy': diagnosis.ampulla_of_vater_accuracy,
        'angiectasia_accuracy': diagnosis.angiectasia_accuracy,
        'blood_fresh_accuracy': diagnosis.blood_fresh_accuracy,
        'blood_hematin_accuracy': diagnosis.blood_hematin_accuracy,
        'erosion_accuracy': diagnosis.erosion_accuracy,
        'erythema_accuracy': diagnosis.erythema_accuracy,
        'foreign_body_accuracy': diagnosis.foreign_body_accuracy,
        'ileocecal_valve_accuracy': diagnosis.ileocecal_valve_accuracy,
        'lymphangiectasia_accuracy': diagnosis.lymphangiectasia_accuracy,
        'normal_clean_mucosa_accuracy': diagnosis.normal_clean_mucosa_accuracy,
        'polyp_accuracy': diagnosis.polyp_accuracy,
        'pylorus_accuracy': diagnosis.pylorus_accuracy,
        'reduced_mucosal_view_accuracy': diagnosis.reduced_mucosal_view_accuracy,
        'ulcer_accuracy': diagnosis.ulcer_accuracy,
    })

@bp.route('/diagnosis/<int:diagnosis_id>', methods=['PUT'])
def update_diagnosis(diagnosis_id):
    # get the diagnosis object from the database
    diagnosis = Diagnosis.query.get_or_404(diagnosis_id)

    # set all fields to 0 except for the one sent in the request
    field = request.json.get('field')
    if field:
        for attribute in Diagnosis.__table__.columns:
            if attribute.name != 'id' and attribute.name != field:
                setattr(diagnosis, attribute.name, 0)
        setattr(diagnosis, field, 1)

    # commit the changes to the database
    db.session.commit()

    # return the updated diagnosis as JSON
    return diagnosis.to_json()