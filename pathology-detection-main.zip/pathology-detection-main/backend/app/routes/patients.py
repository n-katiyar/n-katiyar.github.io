from flask import jsonify, Blueprint, request
from app.models.models import Patient, Doctor
from app.database import db


bp = Blueprint('patients', __name__)

@bp.route('/doctor/<int:doctor_id>/patients', methods=['GET'])
def get_patients_for_doctor(doctor_id):
    try:
        doctor = Doctor.query.get(doctor_id)
        if doctor is None:
            return jsonify({'error': 'Doctor not found'}), 404
        
        patients = Patient.query.filter_by(doctor_id=doctor_id).all()
        
        response = {'patients': [patient.to_dict() for patient in patients]}
        return jsonify(response), 200
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.session.close()

@bp.route('/patient/create', methods=['POST'])
def create_patient():
    name = request.json.get('name')
    age = request.json.get('age')
    doctor_id = request.json.get('doctor_id')

    if not name or not age or not doctor_id:
        return jsonify({'error': 'Please provide all required fields.'}), 400

    # Check if the doctor exists
    if not Doctor.query.filter_by(id=doctor_id).first():
        return jsonify({'error': 'Doctor not found.'}), 404

    patient = Patient(name=name, age=age, doctor_id=doctor_id)

    db.session.add(patient)
    db.session.commit()

    return jsonify({'id': patient.id, 'name': patient.name, 'age': patient.age, 'doctor_id': patient.doctor_id}), 201
