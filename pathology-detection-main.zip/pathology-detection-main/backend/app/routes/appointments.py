from flask import Blueprint, jsonify, request, abort, send_file
# from flask_jwt_extended import get_jwt_identity
# from flask_jwt_extended import jwt_required
from ..database import db
from app.models.models import Appointment, Patient, Image, Diagnosis
import json

from PIL import Image as Im

bp = Blueprint('appointments', __name__)
with open('/home/ec2-user/pathology-detection/backend/app/models/s3_creds.json','r') as f:
    creds = json.load(f)

# s3_client = boto3.client('s3',
#                   aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],
#                   aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],
#                   region_name=creds['AWS_REGION'])

@bp.route('/patient/<int:patient_id>/appointments', methods=['GET'])
def get_appointments_by_patient(patient_id):
    try:
        patient = Patient.query.filter_by(id=patient_id).first()
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        appointments = Appointment.query.filter_by(patient_id=patient_id).all()
        appointment_list = [appointment.to_dict() for appointment in appointments]

        return jsonify(appointment_list), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/appointments/create', methods=['POST'])
def create_appointment():
    data = request.get_json()
    doctor_id = data.get('doctor_id')
    appointment_date = data.get('appointment_date')
    patient_id = data.get('patient_id')
    
    if not all([doctor_id, appointment_date, patient_id]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    appointment = Appointment(patient_id=patient_id, doctor_id=doctor_id, appointment_date=appointment_date)
    db.session.add(appointment)
    db.session.commit()
    return jsonify({'appointment': appointment.to_dict()}), 201

@bp.route('/appointments/<int:appointment_id>', methods=['DELETE'])
def delete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    db.session.delete(appointment)
    db.session.commit()
    return jsonify({'message': 'Appointment deleted successfully'})

@bp.route('/appointments/<int:appointment_id>/total_unprocessed', methods=['GET'])
def get_unprocessed_count(appointment_id):
    # Fetch all images from the database that belong to the appointment
    images = Image.query.filter_by(appointment_id=appointment_id,processed=False).all()
    count = len(images)
    return jsonify({'count': count})

@bp.route('/report', methods=['GET'])
def get_report():
    return send_file('final_demo_report.pdf')
    


