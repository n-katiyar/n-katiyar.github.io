import psycopg2
import json
# open json file with credentials
with open('/home/ec2-user/pathology-detection/backend/app/credentials/creds.json','r') as f:
    creds = json.load(f)

# Set the connection parameters
host = creds['endpoint']
port = '5432'  # default PostgreSQL port
dbname = 'your-db-name-here'
user = creds['username']
password = creds['password']

# Connect to the database
try:
    conn = psycopg2.connect(
        host=host,
        port=port,
        # dbname=dbname,
        user=user,
        password=password
    )
except psycopg2.Error as e:
    print('Unable to connect to the database: {}'.format(e))
    exit(1)

# Create a cursor object
cur = conn.cursor()

# # Create the "hospitals" table
# cur.execute("""
#     CREATE TABLE hospitals (
#         id SERIAL PRIMARY KEY,
#         name VARCHAR(255) NOT NULL
#     );
# """)

# # Create the "doctors" table
# cur.execute("""
#     CREATE TABLE doctors (
#         id SERIAL PRIMARY KEY,
#         name VARCHAR(255) NOT NULL,
#         hospital_id INTEGER REFERENCES hospitals(id)
#     );
# """)

# # Create the "patients" table
# cur.execute("""
#     CREATE TABLE patients (
#         id SERIAL PRIMARY KEY,
#         name VARCHAR(255) NOT NULL,
#         age INTEGER NOT NULL,
#         doctor_id INTEGER REFERENCES doctors(id)
#     );
# """)

# # Create the "appointments" table
# cur.execute("""
#     CREATE TABLE appointments (
#         id SERIAL PRIMARY KEY,
#         appointment_date DATE NOT NULL,
#         patient_id INTEGER REFERENCES patients(id),
#         doctor_id INTEGER REFERENCES doctors(id)
#     );
# """)

# # Create the "images" table
# cur.execute("""
#     CREATE TABLE images (
#         id SERIAL PRIMARY KEY,
#         appointment_id INTEGER NOT NULL,
#         image_name VARCHAR(255),
#         processed BOOLEAN
#     )
# """)

# # Add a foreign key constraint between the "appointments" and "images" tables
# cur.execute("""
#     ALTER TABLE images
#     ADD CONSTRAINT fk_appointment
#     FOREIGN KEY (appointment_id)
#     REFERENCES appointments (id)
#     ON DELETE CASCADE
# """)
# cur.execute("""
#     ALTER TABLE images
#     ADD COLUMN modified BOOLEAN DEFAULT FALSE,
#     ADD COLUMN modified_diagnosis_id INTEGER,
#     ADD COLUMN ai_diagnosis_id INTEGER
# """)
# cur.execute("""
#     CREATE TABLE diagnoses (
#     id SERIAL PRIMARY KEY,
#     ampulla_of_vater_accuracy FLOAT NOT NULL DEFAULT 0,
#     angiectasia_accuracy FLOAT NOT NULL DEFAULT 0,
#     blood_fresh_accuracy FLOAT NOT NULL DEFAULT 0,
#     blood_hematin_accuracy FLOAT NOT NULL DEFAULT 0,
#     erosion_accuracy FLOAT NOT NULL DEFAULT 0,
#     erythema_accuracy FLOAT NOT NULL DEFAULT 0,
#     foreign_body_accuracy FLOAT NOT NULL DEFAULT 0,
#     ileocecal_valve_accuracy FLOAT NOT NULL DEFAULT 0,
#     lymphangiectasia_accuracy FLOAT NOT NULL DEFAULT 0,
#     normal_clean_mucosa_accuracy FLOAT NOT NULL DEFAULT 0,
#     polyp_accuracy FLOAT NOT NULL DEFAULT 0,
#     pylorus_accuracy FLOAT NOT NULL DEFAULT 0,
#     reduced_mucosal_view_accuracy FLOAT NOT NULL DEFAULT 0,
#     ulcer_accuracy FLOAT NOT NULL DEFAULT 0
#     );
# """)
# cur.execute("""
#     ALTER TABLE images
#     ADD CONSTRAINT fk_ai_diagnosis
#     FOREIGN KEY (ai_diagnosis_id)
#     REFERENCES diagnoses (id)
#     ON DELETE SET DEFAULT;
# """)
# Execute the ALTER TABLE statement to add the new column
# alter_query = "ALTER TABLE diagnoses ADD COLUMN other TEXT DEFAULT NULL;"
alter_query = "ALTER TABLE images ADD COLUMN time INTEGER NOT NULL DEFAULT -1;"
cur.execute(alter_query)

# Commit the changes and close the connection
conn.commit()
cur.close()
conn.close()