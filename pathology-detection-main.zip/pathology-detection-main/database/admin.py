import psycopg2
import json
# open json file with credentials
with open('credentials/creds.json') as f:
    creds = json.load(f)

# Set the connection parameters
host = creds['endpoint']
port = '5432'  # default PostgreSQL port
dbname = 'your-db-name-here'
user = creds['username']
password = creds['password']

# Connect to the database
try:
    conn = psycopg2.connect(
        host=host,
        port=port,
        # dbname=dbname,
        user=user,
        password=password
    )
except psycopg2.Error as e:
    print('Unable to connect to the database: {}'.format(e))
    exit(1)

# Define the image ID that you want to delete
image_id = 1

# Create a cursor object
cur = conn.cursor()

try:
    # Execute the delete query
    cur.execute("DELETE FROM images WHERE id = %s", (image_id,))

    # Commit the changes to the database
    conn.commit()

    print("Image deleted successfully")

except Exception as e:
    # Rollback the changes if there was an error
    conn.rollback()
    print("Error deleting image:", e)

finally:
    # Close the cursor and connection objects
    cur.close()
    conn.close()