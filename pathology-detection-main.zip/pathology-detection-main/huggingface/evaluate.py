from transformers import AutoConfig, AutoModelForImageClassification, AutoImageProcessor
from datasets import load_dataset
import os
from accelerate.utils import set_seed
import torch
from torch.utils.data import DataLoader
import evaluate
from sklearn.metrics import confusion_matrix
import numpy as np
from accelerate import Accelerator
import matplotlib.pyplot as plt
from huggingface_hub import hf_hub_download

set_seed(42)
REPO_ID = "emi429/vit-ksavir"
FILENAME = "vit-ksavir"
train_dir = ''
batch_size=8
labels =   ['Ampulla of vater', 'Angiectasia', 'Blood - fresh', 'Blood - hematin', 'Erosion', 'Erythema', 'Foreign body', 'Ileocecal valve', 'Lymphangiectasia', 'Normal clean mucosa', 'Polyp', 'Pylorus', 'Reduced mucosal view', 'Ulcer']
label2id = {label: str(i) for i, label in enumerate(labels)}
id2label = {str(i): label for i, label in enumerate(labels)}

config = AutoConfig.from_pretrained(
            REPO_ID,
            num_labels=len(labels),
            i2label=id2label,
            label2id=label2id,
            finetuning_task="image-classification",
        )
    
model = AutoModelForImageClassification.from_pretrained(
    REPO_ID,
    from_tf=False,
    config=config,
    ignore_mismatched_sizes=False,
)

image_processor = AutoImageProcessor.from_pretrained(REPO_ID)

accelerator = Accelerator(gradient_accumulation_steps=1,mixed_precision='bf16')

data_files = {}
data_files["train"] = os.path.join(train_dir, "**")
dataset = load_dataset(
    "imagefolder",
    data_files=data_files,
    # cache_dir=args.cache_dir,
    task="image-classification",
)
split = dataset["train"].train_test_split(0.2,stratify_by_column="labels")
dataset["train"] = split["train"]
dataset["validation"] = split["test"]
# DataLoaders creation:
def collate_fn(examples):
    pixel_values = torch.stack([example["pixel_values"] for example in examples])
    labels = torch.tensor([example["labels"] for example in examples])
    return {"pixel_values": pixel_values, "labels": labels}

eval_dataloader = DataLoader(dataset["validation"], collate_fn=collate_fn, batch_size=batch_size)

# Get the metric function
metric_accuracy = evaluate.load("accuracy")
metric_f1 = evaluate.load("f1")
metric_precision = evaluate.load("precision")
metric_recall = evaluate.load("recall")

actual = []
predicted = []
for step, batch in enumerate(eval_dataloader):
    with torch.no_grad():
        outputs = model(**batch)
    predictions = outputs.logits.argmax(dim=-1)
    predictions, references = accelerator.gather_for_metrics((predictions, batch["labels"]))
    actual.extend(references.tolist())
    predicted.extend(predictions.tolist())
    metric_accuracy.add_batch(
        predictions=predictions,
        references=references,
    )
    metric_f1.add_batch(
        predictions=predictions,
        references=references,
    )
    metric_precision.add_batch(
        predictions=predictions,
        references=references,
    )
    metric_recall.add_batch(
        predictions=predictions,
        references=references,
    )

eval_metric_accuracy = metric_accuracy.compute()
eval_metric_f1 = metric_f1.compute(average=None)
eval_metric_precision = metric_precision.compute(average=None)
eval_metric_recall = metric_recall.compute(average=None)

# Get the confusion matrix for the entire validation set
cm = confusion_matrix(np.array(actual), np.array(predicted))
# Plot the confusion matrix as a pyplot
# Plot confusion matrix
fig, ax = plt.subplots(figsize=(5, 5))
ax.matshow(confusion_matrix, cmap=plt.cm.Blues)

for i in range(confusion_matrix.shape[0]):
    for j in range(confusion_matrix.shape[1]):
        ax.text(x=j, y=i,s=confusion_matrix[i, j], va='center', ha='center')

plt.xlabel('Predictions')
plt.ylabel('Actuals')
plt.title('Confusion Matrix')
plt.savefig('confusion_matrix.png')
plt.show()

