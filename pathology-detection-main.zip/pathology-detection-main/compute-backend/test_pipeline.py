from pipeline import load_image_processing_pipeline, predict
from PIL import Image
import io
# from visualization_attention import process_attentions, save_attentions

# Generate a sample batch.
test_folder = "test"
image1 = io.BytesIO()
image2 = io.BytesIO()
# Image.open('test/angiectasia.jpg').save(image1, format='JPEG')
Image.open('test/blood_fresh_2.jpg').save(image2, format='JPEG')
json_data = {'images':[image2]}

model,image_processor = load_image_processing_pipeline("model")
predictions= predict(json_data,model,image_processor)
print(predictions)
# attentions = process_attentions(attention_weights)
# save_attentions(attentions, "attention_maps",mean=True)

