import boto3
from PIL import Image
import json
import io

with open('/home/emile/capai/pathology-detection/api/credentials/creds.json','r') as f:
    creds = json.load(f)
runtime = boto3.client("sagemaker-runtime",aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],region_name=creds['AWS_REGION'])

endpoint_name = "image-classification"
content_type = "image/jpeg"
image = Image.open('test/blood_fresh_2.jpg')
# Convert the image to bytes
with io.BytesIO() as buffer:
    image.save(buffer, format='JPEG')
    payload_bytes = buffer.getvalue()
# payload = {
#     "inputs":'https://capm-ai.s3.ca-central-1.amazonaws.com/1-blood_fresh.jpg'
# }

# payload_bytes = json.dumps(payload).encode('utf-8')


response = runtime.invoke_endpoint(
    EndpointName=endpoint_name,
    ContentType=content_type,
    Body=payload_bytes
)
# Parse the response body
response_body = response['Body'].read().decode('utf-8')
response_json = json.loads(response_body)

# # Extract the classification scores
# scores = response_json['scores']

# # Print the scores
for score in response_json:
    print(score)
# print(response_json)