from transformers import AutoConfig, AutoImageProcessor, AutoModelForImageClassification
import torch
from PIL import Image
from transformers import pipeline, set_seed
from transformers import BioGptTokenizer, BioGptForCausalLM

def batchify(json_object,image_processor):
    """batchify a json object."""
    batch = [Image.open(image).convert('RGB') for image in json_object["images"]]
    batch = image_processor.preprocess(batch, return_tensors="pt")
    return batch

def predict(json_images,model,image_processor,attention_outputs=False):
    """Predict on a batch."""
    batch = batchify(json_images,image_processor)
    batch['output_attentions'] = attention_outputs
    with torch.no_grad():
        outputs = model(**batch)
        # print(outputs)
        logits = outputs.logits
        probs = torch.nn.functional.softmax(logits, dim=-1)
        if not attention_outputs:
            return probs
        else:
            return probs,outputs.attentions

def convert_predictions_to_labels(probs):
    """Convert predictions to labels."""
    labels =   ['Ampulla of vater', 'Angiectasia', 'Blood - fresh', 'Blood - hematin', 'Erosion', 'Erythema', 'Foreign body', 'Ileocecal valve', 'Lymphangiectasia', 'Normal clean mucosa', 'Polyp', 'Pylorus', 'Reduced mucosal view', 'Ulcer']
    _, preds = torch.max(probs, dim=1)
    return [labels[pred] for pred in preds]

def generate_json(probs):
    human_labels = convert_predictions_to_labels(probs)
    json = {'probabilities':probs.numpy().tolist(),
            'classification':human_labels}
    return json

def load_image_processing_pipeline(path):
    # Prepare label mappings.
    # We'll include these in the model's config to get human readable labels in the Inference API.
    labels =   ['Ampulla of vater', 'Angiectasia', 'Blood - fresh', 'Blood - hematin', 'Erosion', 'Erythema', 'Foreign body', 'Ileocecal valve', 'Lymphangiectasia', 'Normal clean mucosa', 'Polyp', 'Pylorus', 'Reduced mucosal view', 'Ulcer']
    label2id = {label: str(i) for i, label in enumerate(labels)}
    id2label = {str(i): label for i, label in enumerate(labels)}


    config = AutoConfig.from_pretrained(
            path,
            num_labels=len(labels),
            i2label=id2label,
            label2id=label2id,
            finetuning_task="image-classification",
        )
    
    model = AutoModelForImageClassification.from_pretrained(
        path,
        from_tf=False,
        config=config,
        ignore_mismatched_sizes=False,
    )
    
    image_processor = AutoImageProcessor.from_pretrained(path)

    return model, image_processor

def answer_question(generator,message):
    message = message
    return generator(message, max_length=100, num_return_sequences=5, do_sample=True)
    
def initialize_chat_pipeline():
    pipe_biogpt = pipeline("text-generation", model="microsoft/BioGPT-Large", device="cuda:0")
    return pipe_biogpt