import requests
import json
from datetime import datetime

def create_hospital(name):
    url = "http://localhost:5000/api/hospital/create"
    data = {"name": name}
    response = requests.post(url, json=data)
    if response.status_code == 201:
        print("Hospital created successfully:",response.text)
    else:
        print("Error creating hospital: ", response.text)

def create_doctor(name, hospital_id):
    url = "http://localhost:80/api/doctor/create"
    data = {'name': name, 'hospital_id': hospital_id}
    response = requests.post(url, json=data)

    if response.status_code == 201:
        result = response.json()
        print(f"Doctor created with id: {result['id']}, name: {result['name']}, hospital_id: {result['hospital_id']}")
    else:
        print(f"Failed to create doctor. Error message: {response.json()['message']}")

def create_patient():
    url = 'http://localhost:5000/api/patient/create'
    data = {
        'name': 'John Smith the third',
        'age': 30,
        'doctor_id': 1
    }
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, headers=headers, data=json.dumps(data))
    if response.status_code == 201:
        print('Patient created successfully.')
        print(response.json())
    else:
        print('Error creating patient.',response.json)

def test_get_patients_by_doctor():
    # Replace <doctor_id> with the actual doctor id you want to retrieve patients for
    url = f"http://localhost:80/doctor/1/patients"
    response = requests.get(url)
    print(response.json())

def test_get_hospitals():
    url = 'http://localhost:5000/hospitals'
    response = requests.get(url)
    if response.status_code == 200:
        hospitals = response.json()
        for hospital in hospitals:
            print(hospital)
    else:
        print(f'Error: {response.status_code}')

def create_appointment():
    url = 'http://localhost:80/appointments/patients/1/appointments'
    data = { 
            'appointment_date': str(datetime.now()),
            'patient_id': 1,
            'doctor_id': 1
    }
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, headers=headers, data=json.dumps(data))
    if response.status_code == 201:
        print('Patient created successfully.')
        print(response.json())
    else:
        print('Error creating patient.',response.json)

# create_hospital("Montreal General Hospital")
create_doctor("Alice Doe",1)
# create_patient()
# test_get_patients_by_doctor()
# test_get_hospitals()
# create_appointment()