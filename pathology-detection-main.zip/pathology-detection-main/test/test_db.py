import psycopg2
import json
# open json file with credentials
with open('../backend/app/credentials/creds.json') as f:
    creds = json.load(f)

# Set the connection parameters
host = creds['endpoint']
port = '5432'  # default PostgreSQL port
dbname = 'your-db-name-here'
user = creds['username']
password = creds['password']
conn = psycopg2.connect(
        host=host,
        port=port,
        # dbname=dbname,
        user=user,
        password=password
    )

def show_hospitals():
    cur = conn.cursor()
    cur.execute("SELECT * FROM hospitals")
    rows = cur.fetchall()
    for row in rows:
        print(f"Hospitals: {row}")
    cur.close()
    

def show_doctors():
    cur = conn.cursor()
    cur.execute("SELECT * FROM doctors")
    rows = cur.fetchall()
    for row in rows:
        print(f"Doctors: {row}")
    cur.close()

def show_appointments():
    cur = conn.cursor()
    cur.execute("SELECT * FROM appointments")
    rows = cur.fetchall()
    for row in rows:
        print(f"appointments: {row}")
    cur.close()

show_hospitals()
show_doctors()
show_appointments()
conn.close()
