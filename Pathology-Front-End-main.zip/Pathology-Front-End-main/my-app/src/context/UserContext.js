import { createContext } from 'react';
const UserContext = createContext({
    currentPatient: null,
    currentAppointment: null,
    currentDoctor: null,
    setCurrentPatient: () => {},
    setCurrentAppointment: () => {},
    setCurrentDoctor: () => {},
});

export default UserContext;