import { Grid, Typography, FormControlLabel,FormControl, RadioGroup, Radio, TextField, FormLabel, Button, MenuItem } from "@mui/material"
import { useState, useEffect } from "react"
import { api } from "../../components/api";
import { diseases } from "../../components/navbar/consts/mainEditorItems";



const EditImage = (props) => {
    const { imageData, onClose} = props;
    const [maxDiagnosis, setMaxDiagnosis] = useState('');
    const [selectedRadio, setSelectedRadio] = useState('keep');
    const [disableConfirm, setdisableConfirm] = useState('true');
    const [manualDiagnosis, setManualDiagnosis] = useState('');
    const handleRadioChange = (event) => {
        setSelectedRadio(event.target.value);
        if (event.target.value !== 'keep'){
            setdisableConfirm(false);
        }else{
            setdisableConfirm(true);
        }
      };
    
    const handleConfirm = () => {
      if (selectedRadio === 'remove'){
        handleRemoveImage();
        onClose();
        console.log('Removing ', imageData.id)
      }else if (selectedRadio === 'change'){
        handleChangeImage();
        console.log('Changing ', imageData.id)
      }
      
    };
    function handleChangeImage() {
      let newDiagnosis = {
        'ampulla_of_vater_accuracy': 0,
        'angiectasia_accuracy': 0,
        'blood_fresh_accuracy': 0,
        'blood_hematin_accuracy': 0,
        'erosion_accuracy': 0,
        'erythema_accuracy': 0,
        'foreign_body_accuracy': 0,
        'ileocecal_valve_accuracy': 0,
        'lymphangiectasia_accuracy': 0,
        'normal_clean_mucosa_accuracy': 0,
        'polyp_accuracy': 0,
        'pylorus_accuracy': 0,
        'reduced_mucosal_view_accuracy': 0,
        'ulcer_accuracy': 0,
      }
      newDiagnosis[manualDiagnosis] = 1;
      fetch(api.url+`images/${imageData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(
          newDiagnosis
        )
      })
      .then(response => response.json())
      .then(data => {console.log(data); onClose();})
      .catch(error => console.error(error));
    }
    function handleRemoveImage() {
      fetch(api.url+`images/${imageData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ampulla_of_vater_accuracy: 0,
          angiectasia_accuracy: 0,
          blood_fresh_accuracy: 0,
          blood_hematin_accuracy: 0,
          erosion_accuracy: 0,
          erythema_accuracy: 0,
          foreign_body_accuracy: 0,
          ileocecal_valve_accuracy: 0,
          lymphangiectasia_accuracy: 0,
          normal_clean_mucosa_accuracy: 1,
          polyp_accuracy: 0,
          pylorus_accuracy: 0,
          reduced_mucosal_view_accuracy: 0,
          ulcer_accuracy: 0,
        })
      })
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => console.error(error));
    }

    useEffect( () => {
      const diagnosisId = imageData.modified?imageData.modified_diagnosis_id:imageData.ai_diagnosis_id;
      console.log(diagnosisId)
      fetch(api.gateway_url+`diagnosis/${diagnosisId}`,{
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
      })
      .then(response => {
        return response.json();
      })
			.then(data => {
        let body = JSON.parse(data.body);
        setMaxDiagnosis(getMaxDiagnosis(body));
			})
			.catch(error => console.error(error));
    },[imageData])

    function getMaxDiagnosis(diagnosis) {
      const maxValues = Object.assign({}, diagnosis);
      delete maxValues.id;
      const maxValuesArray = Object.values(maxValues);
      const max = Math.max(...maxValuesArray);
      const maxKey = Object.keys(maxValues).find(key => maxValues[key] === max)
      
      const maxDiagnosisTemp = {
        key: maxKey,
        value: max,
        label: diseases.find(label => label.value === maxKey).label
      }
      console.log(maxKey)
      return maxDiagnosisTemp
    }

    function handleDiagnosisChange(event) {
      setManualDiagnosis(event.target.value);
    }

    return (
        <Grid item container
            direction="row"
            alignItems="center"
            justifyContent="center" wrap='nowrap'
            spacing={2}>
                <Grid item container direction='column' alignItems="end"
                    wrap='nowrap'>
                        <img
                            src={imageData.image_url}
                            loading="lazy"
                            alt=""
                        />
                    <Typography>
                        Diagnosis: {maxDiagnosis.label}
                    </Typography>
                    <Typography>
                        Certainty: {maxDiagnosis.value*100}%
                    </Typography>
                </Grid>
                <Grid item container direction='row' wrap='nowrap' justifyContent={'start'}>
                    <FormControl>
                    <FormLabel id="demo-radio-buttons-group-label">Action</FormLabel>
                        <RadioGroup
                            aria-labelledby="demo-radio-buttons-group-label"
                            defaultValue="keep"
                            name="radio-buttons-group"
                            value={selectedRadio} onChange={handleRadioChange}
                        >
                            <FormControlLabel value="keep" control={<Radio />} label="Keep" />
                            <FormControlLabel value="remove" control={<Radio />} label="Remove" />
                            <FormControlLabel value="change" control={<Radio />} label="Change" />
                            
                        </RadioGroup>
                        <Button variant="outlined" disabled={disableConfirm} onClick={handleConfirm}>Confirm</Button>
                    </FormControl>
                    <Grid item container direction='column' wrap='nowrap' justifyContent={'end'} sx={{ marginLeft: '2rem' }}>
                    <TextField  label={'Diagnosis'} 
                                sx={{width: '200px'}} 
                                disabled={selectedRadio !== 'change'} 
                                select 
                                defaultValue={'normal_clean_mucosa_accuracy'}
                                value={manualDiagnosis? manualDiagnosis:maxDiagnosis.key || ''}
                                onChange={(e) => handleDiagnosisChange(e)}
                                >
                        {diseases.map((option) => (
                            <MenuItem key={option.value} value={option.value}>
                            {option.label}
                            </MenuItem>
                        ))}
                    </TextField>
                    <TextField label={'Additional Information'} multiline sx={{width: '200px'}} disabled={selectedRadio !== 'change'}/>
                    </Grid>

                </Grid>
            </Grid>
    )
}
export default EditImage