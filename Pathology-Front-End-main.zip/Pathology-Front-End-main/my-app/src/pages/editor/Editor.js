import Grid from '@mui/material/Grid';
import { ImageList, ImageListItem,ImageListItemBar, Button} from "@mui/material";
import { api } from "../../components/api";
import { useState, useEffect, useContext} from 'react';
import Pagination from '@mui/material/Pagination';
import EditImage from './EditImage';
import DeselectIcon from '@mui/icons-material/Deselect';
import UserContext from '../../context/UserContext';
import { diseases } from '../../components/navbar/consts/mainEditorItems';

export default function Editor() {
	const [imageData, setImageData] = useState([]);
	const [pageNumber, setPageNumber] = useState(1);
	const [totalPages, setTotalPages] = useState(1);
	const [selectedImage, setSelectedImage] = useState(null);
	const { currentPatient, currentAppointment } = useContext(UserContext);
	const [updateImageData, setUpdateImageData] = useState(0);

	useEffect(() => {
		if (currentAppointment) {
		//   fetch(api.url+`appointments/${currentAppointment.id}/images?page=${pageNumber}`)
		fetch(api.gateway_url + `images/${currentAppointment.id}?page=${pageNumber}`, {
			headers: {
			  'Content-Type': 'application/json'
			}
		  })
			.then(response => {
				return response.json();
			})
			.then(data => {
			  let body = JSON.parse(data.body);
			  setImageData(body.images);
			//   console.log(data.images)
			  setTotalPages(body.total_pages);
			//   data.images.map((image, index) => (console.log(image)))
			})
			.catch(error => console.error(error));
		} else {
		  // Handle null case
		  console.log("No appointment selected")
		}
	  }, [pageNumber,currentAppointment, updateImageData]);

	useEffect(() => {
		setSelectedImage(null);
	},[currentPatient, currentAppointment])


	const handlePageChange = (event, value) => {
		setPageNumber(value);
	};
	
	const handleImageClick = (index) => {
		setSelectedImage(index);
	};
	const imageStyle = (index) => {
		return {
			width: '112px',
			height: '112px',
			objectFit: 'cover',
			boxSizing: 'border-box',
			padding: '0rem',
			cursor: "pointer",
			border: selectedImage === index ? 'solid 4px #0066cc' : 'none',
			borderRadius: '10px',
		}
	};
	const handlePageClick = () => {
		// console.log("page click")
		setSelectedImage(null);
	};
	const handleCloseEditImage = () => {
		setSelectedImage(null)
		setUpdateImageData(prevKey => prevKey + 1)
		// console.log(imageData[selectedImage].modified)
	}
	const downloadFile = () => {
		fetch(api.url+"report")
		  .then((response) => response.blob())
		  .then(blob => {
			// create a new anchor element
			const url = window.URL.createObjectURL(new Blob([blob]));
			const a = document.createElement('a');
			a.href = url;
			a.download = 'MyEndoscopyReport.pdf';
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			// cleanup the URL object
			window.URL.revokeObjectURL(url);
		  })
		  .catch(error => {
			console.error('Error:', error);
		  });
		
	  };

		return (
			<Grid item container sx={{
					height: "100vh"
					}}
				direction="column"
				alignItems="center"
				justifyContent="flex-end" wrap='nowrap'>
					{selectedImage !== null && (
						<EditImage 
							imageData={imageData[selectedImage]} 
							onClose={handleCloseEditImage}
							key={selectedImage}
						/>
					)}
					
				<ImageList cols={5}>
				{imageData && imageData
				.sort((a, b) => a.image_url.localeCompare(b.image_url)) // sort by name
				.map((image, index) => (
					<ImageListItem key={index} onClick={() => handleImageClick(index)}>
					<img
						src={image.image_url}
						loading="lazy"
						style={imageStyle(index)}
						alt=""
					/>
					<ImageListItemBar
						title={image.modified? diseases.find(disease => disease.value === image.modified_diagnosis.max_diagnosis.name).label : diseases.find(disease => disease.value === image.ai_diagnosis.max_diagnosis.name).label}
						subtitle={image.modified? Math.round(image.modified_diagnosis.max_diagnosis.accuracy *100) +"%" : Math.round(image.ai_diagnosis.max_diagnosis.accuracy *100)+"%"}
						position="below"
					/>
					</ImageListItem>
				))}
				</ImageList>
				
				<Grid container alignItems="center" justifyContent="center" spacing={2}>
					<Grid item>
						<DeselectIcon onClick={handlePageClick} style={{ marginRight: "auto", cursor: "pointer" }}/>
					</Grid>
					<Grid item>
						<Pagination count={totalPages} page={pageNumber} onChange={handlePageChange} />
					</Grid>
					<Grid item>
						<Button variant="contained" color="primary" onClick={downloadFile}>Generate Report</Button>
					</Grid>
				</Grid>
			</Grid>
				
		);
}