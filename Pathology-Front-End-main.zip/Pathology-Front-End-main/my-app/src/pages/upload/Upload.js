import Grid from '@mui/material/Grid';
import DropZoneBox from '../../components/common/DropZoneBox';
import React, { useState, useCallback, useContext } from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import { api } from '../../components/api';
import UserContext from '../../context/UserContext';

import ConfirmationDialog from '../../components/common/ConfirmationDialog';
import JSZip from 'jszip';
import UploadingPopup from './UploadingPopup';
import { useNavigate } from 'react-router';


export default function Upload() {
    const [files, setFiles] = useState([]);
    const [isUploading, setIsUploading] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [confirmDialog, setConfirmDialog] = useState(false)
    const [allImageProcessedError, setAllImageProcessedError] = useState(false)
    const [isProgressBarEnabled, setIsProgressBarEnabled] = useState(false);
    const { currentAppointment} = useContext(UserContext);
    const navigate = useNavigate();
    
    const onDrop = useCallback(async (acceptedFiles) => {
      const newFiles = [];
      setIsProcessing(true);
      for (const file of acceptedFiles) {
        if (file.type.startsWith('image/')) {
          newFiles.push(file);
        } else if (file.type.startsWith('application/x-zip-compressed') || file.type.startsWith('application/zip')) {
          const zip = new JSZip();
          const contents = await zip.loadAsync(file);
          for (const [relativePath, zipEntry] of Object.entries(contents.files)) {
            if (!zipEntry.dir && zipEntry.name.match(/\.(jpeg|jpg|png)$/i)) {
              const uncompressedContent = await zipEntry.async("blob");
              const extractedFile = new File([uncompressedContent], zipEntry.name, { type: uncompressedContent.type });
              newFiles.push(extractedFile);
            }
          }
        } else {
          console.log(`${file.name} is not an image or a zip file. It is a ${file.type}`);
        }
      }
      console.log(newFiles)
      setFiles((prevFiles) => [...prevFiles, ...newFiles]);
      setIsProcessing(false);
    }, []);
    
    // const processFiles = () => {
    //   if (currentAppointment) {
    //     setIsProgressBarEnabled(true);
    //     fetch(api.url + 'appointments/'+currentAppointment.id +'/total_unprocessed')
    //     .then(response => {
    //       if (response.ok) {
    //         return response.json();
    //       } else {
    //         throw new Error('Failed to get total unprocessed images');
    //       }
    //     })
    //     .then(data => {
    //       console.log(data)
    //       if(data.count>0)
    //         setProgressBarTotalCount(data.count)
    //       else
    //         setAllImageProcessedError(true)
    //     })
    //     fetch(api.url + 'appointments/'+currentAppointment.id +'/process_images')
    //       .then(response => {
    //         if (response.ok) {
    //           return response.json();
    //         } else {
    //           throw new Error('Failed to send images');
    //         }
    //       })
    //       .then(data => {
    //         console.log(data)
    //         if(data.count+progressBarValue>=progressBarTotalCount){
    //           setIsProgressBarEnabled(false)
    //           setProgressBarValue(0)
    //           setProgressBarTotalCount(0)
    //         }
    //         setProgressBarValue(data.count+progressBarValue)
    //       })
    //       .catch(error => {
    //         console.error('Failed to fetch appointment images', error);
    //       });
    //   } else {
    //     setConfirmDialog(true)
    //   }
    // };

    const handleUploadButton = () => {
      if(currentAppointment){
        setIsUploading(true)
      }else{
        setConfirmDialog(true)
      }
    }
    const handleUploadFinished = () => {
      setFiles([])
      navigate('/editor')
      console.log('upload finished')
    }

    
    return (
            <Grid container sx={{
                height: "50vh"
                }}
              direction="column"
              alignItems="center"
              wrap='nowrap'>
                <Box mt={20}>
                    <DropZoneBox onDrop={onDrop}/>
                    <Box mt={2} textAlign='center'>
                        <Button variant="outlined" onClick={handleUploadButton} disabled={files.length===0?true:false}>Upload</Button>
                    </Box>  
                    
                </Box>
                {/* <Box mt={5} sx={{width:"25%"}}>
                  {isProgressBarEnabled && (
                <LinearProgress variant="determinate" color="primary" value={Math.round((progressBarValue / progressBarTotalCount) * 100)} />
                )}
                {isProcessing && (
                  <LinearProgress />
                )}
                </Box> */}
                {isUploading && currentAppointment && (
                <UploadingPopup onClose = {() => setIsUploading(false)} files={files} isOpen={isUploading} onFinished={handleUploadFinished}/>
                )}
                
                    
                {confirmDialog && (
              <ConfirmationDialog
                isOpen={confirmDialog}
                title="Appointment not selected"
                message={"You must selected an appointment before uploading images. Appointments can be selected on the menu on the right under a selected patient."}
                buttonText="Delete"
                onClose={() => setConfirmDialog(false)}
                onConfirm={() => setConfirmDialog(false)}
              />
            )} 
            {allImageProcessedError && (
              <ConfirmationDialog
                isOpen={allImageProcessedError}
                title="All images processed"
                message={"All images have already been processed. If you would like to process more images, please upload new images. Processed images can be accessed in the Editor tab."}
                buttonText="Delete"
                onClose={() => setAllImageProcessedError(false)}
                onConfirm={() => setAllImageProcessedError(false)}
              />
            )}             
            </Grid>
    );
}