import React from 'react';
import UserContext from '../../context/UserContext';
import { LinearProgress, Dialog, DialogTitle, DialogContent } from '@mui/material';
import { useState, useContext, useRef } from 'react';
import { api } from '../../components/api';
import { useEffect } from 'react';
function UploadingPopup(props) {
  // const [progressBarTotalCount, setProgressBarTotalCount] = useState(0);
  // const [progressBarCurrentCount, setProgressBarCurrentCount] = useState(0);
  const { currentAppointment} = useContext(UserContext);
  const [dialogText, setDialogText] = useState("Uploading images, please wait.");
  const hasMountedRef = useRef(false);
  const files = props.files;

  // You can customize the style of the popup and its content
  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'white',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };
  const handleClose = () => {
    props.onClose();
    // setUploaded(false);
  };

  // Create a function to convert a binary file to a base64 string
  function convertToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result.replace(/^data:.+;base64,/, ''));
      reader.onerror = (error) => reject(error);
    });
  }

  useEffect(() => {
    if(currentAppointment && !hasMountedRef.current){
      setDialogText("Uploading images, please wait.");
      hasMountedRef.current = true;
      console.log('files uploading...', files)
      const filesPerChunk = 20; // number of files to send in each chunk
      const totalChunks = Math.ceil(files.length / filesPerChunk);
      console.log(totalChunks)
  
      let counter = 0; // to keep track of the number of successfully uploaded chunks
  
      const uploadChunks = async () => {
        for (let i = 0; i < totalChunks; i++) {
          const start = i * filesPerChunk;
          const end = (i + 1) * filesPerChunk;
          const filesChunk = files.slice(start, end);
          
          const formData = new FormData();
          console.log(filesChunk)
          
          // Create an array to hold promises for each file
          const promises = [];

          // Convert each file to base64 and append it to an array of image objects
          const images = [];
          filesChunk.forEach((file) => {
            const promise = convertToBase64(file)
              .then((base64String) => {
                images.push({ data: base64String });
              })
              .catch((error) => console.error(error));
            promises.push(promise);
          });

          // Wait for all promises to complete before sending the request
          Promise.all(promises).then(() => {
            const payload = {
              appointment_id: currentAppointment.id,
              processed: false,
              modified: false,
              images: images,
            };

            fetch('https://ulpawdzp8e.execute-api.ca-central-1.amazonaws.com/test/images', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(payload),
            })
              .then((response) => {
                if (!response.ok) {
                  console.log(response.json());
                  throw new Error('Failed to send images');
                }
                return response.text(); // read the stream as text
              })
              .then((data) => {
                console.log(data); // log the data
                counter++;
                if (counter === totalChunks) {
                  // check if all chunks have been uploaded
                  handleFinished();
                }
              })
              .catch((error) => {
                console.error('Failed to fetch appointment images', error);
                setDialogText('Upload failed');
              });
          });
          // try {
          //   const response = await fetch('https://ulpawdzp8e.execute-api.ca-central-1.amazonaws.com/test/images', {
          //     method: 'POST',
          //     headers: {
          //       'Content-Type': 'application/json',
          //     },
          //     body: formData,
          //   });
          //   if (!response.ok) {
          //     console.log(response)
          //     throw new Error('Failed to send images');
          //   }
          //   const data = await response.json();
          //   console.log(data);
          //   counter++; // increment the counter for each successful upload
          // } catch (error) {
          //   console.error('Failed to fetch appointment images', error);
          // }
          
        }    
      };
  
      uploadChunks();
    }
  }, []);

  const handleFinished = () => {
    // for demo only
    setDialogText("Finished uploading images!");

    // end of demo script
    // setDialogText("Finished uploading images!");
    setTimeout(() => {
      handleClose();
      props.onFinished();
    }, 3000);
    
  };

  return (
    <Dialog
      open={props.isOpen}
      onClose={handleClose}
    >
      <DialogTitle>{"Uploading"}</DialogTitle>
      <DialogContent> {dialogText} </DialogContent>
      <DialogContent>         
        <LinearProgress id="popup-modal-description" /> 
      </DialogContent>
      
      {/* <div style={style}>
        <Typography id="popup-modal-title" variant="h6" component="h2">
          Uploading...
        </Typography>
        <Button></Button>
        <LinearProgress id="popup-modal-description" />
      </div> */}
    </Dialog>
  );
}

export default UploadingPopup;