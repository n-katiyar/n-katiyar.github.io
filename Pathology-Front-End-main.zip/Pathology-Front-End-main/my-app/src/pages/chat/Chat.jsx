import React from 'react';
import { Grid } from '@mui/material';
import TextField from '@mui/material/TextField';
// import { withStyles } from '@mui/material/styles';


class Message extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
            id: this.props.id,
            message: this.props.message,
            senderName: this.props.senderName
        }
        
    }  
}

class Chat extends React.Component {
    constructor(props) {
        super(props);
        this.classes = this.props.classes;
        this.state = {
          isTyping: false,
          messages: [
            new Message({ id: 1, message: "Hi there! How can I help you?", senderName: "BioGPT" }),
            // new Message({ id: 2, message: "Hi there! help me :)?", senderName: "You" }),
          ],
          currentUser: "You",
          
        };
        this.keyPress = this.keyPress.bind(this);
      }
      keyPress(e){
        if(e.keyCode == 13){
            this.setState({messages:[...this.state.messages, new Message({ id: this.state.messages.length+1, message: e.target.value, senderName: this.state.currentUser })]})
           this.sendMessage(e.target.value)
           e.preventDefault();
           e.target.value = "";
        }
     }
    
     sendMessage(message) {
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message })
        };
        fetch('http://127.0.0.1:5000/chat', requestOptions)
            .then(response => response.json())
            .then(data => this.setState({
                messages:[
                    ...this.state.messages,
                    new Message({
                        id: this.state.messages.length+1,
                        message: data.message,
                        senderName: 'BioGPT' })
                    ]
                })
            );
     }
    render() {
        const messages = this.state.messages;
        const textBoxes = messages.map((message) => {
            let textAlign='right'
            if (message.props.senderName !== "You"){
                textAlign='left'
            }
            return (
                // <Grid item xs={12} md={12}>
                    <TextField
                        id="outlined-textarea"
                        placeholder={"Enter your message here..."}
                        defaultValue={message.props.message}
                        multiline
                        fullWidth
                        sx={{width: '500px'}}
                        inputProps={{disabled: true,  style:{textAlign: textAlign}}}
                        key={message.id}
                        />
                // {/* </Grid> */}
            );
        });
        return (
        <Grid container item sx={{
            height: "100vh"
            }}
          direction="column"
          alignItems="center"
          justifyContent="flex-end" wrap='nowrap'>
            
            {textBoxes}

            <TextField
            id="outlined-textarea"
            placeholder={"Enter your message here..."}
            multiline
            fullWidth
            sx={{width: '500px'}}
            onKeyDown={this.keyPress}
            
            />
        </Grid>
        );
    };

}
// const StyleChat = withStyles(muiStyles)(Chat);
export default Chat