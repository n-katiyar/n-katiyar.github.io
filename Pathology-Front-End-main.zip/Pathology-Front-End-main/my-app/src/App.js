import React, { useState } from "react";
import UserContext from "./context/UserContext";
import Home from './pages/home/Home';
import Editor from './pages/editor/Editor';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import SignInSide from './pages/signin/SignInSide';
import Upload from './pages/upload/Upload';
import ErrorPage from './error-page'
import Chat from './pages/chat/Chat';
import Signup from './pages/signup/SignUp';
import { Amplify } from 'aws-amplify';
// import awsExports from './aws-exports';
// Amplify.configure(awsExports);


function App() {
  const [currentPatient, setCurrentPatient] = useState(null);
  const [currentAppointment, setCurrentAppointment] = useState(null);
  const [currentDoctor, setCurrentDoctor] = useState(null);
  // Pass an object that contains all the values and methods you want to share
  const userValue = {
      currentPatient,
      currentAppointment,
      currentDoctor,
      setCurrentPatient,
      setCurrentAppointment,
      setCurrentDoctor,
      };
    

  const router = createBrowserRouter([
    {
    path: "/",
    element:<Home/>,
    errorElement: <ErrorPage />,
    children: [
      {
        path: "/editor/",
        element: <Editor />,
      },
      // {
      //   path: "home",
      //   element: <Home />,
      // },
      {
        path: "upload",
        element: <Upload />,
      },
      {
        path: "chat",
        element: <Chat />,
      }
    ],
  },
  {
    path: "signin",
    element: <SignInSide />,
  },
  {
    path: "signup",
    element: <Signup/>,
  }
  ]);
  
  return (
    <React.StrictMode>
      <UserContext.Provider value={userValue}>
        <RouterProvider router={router}/>
      </UserContext.Provider>
    </React.StrictMode>
  );

}

export default App;