import React, { useState } from "react";
import { List, ListItem, ListItemText, Collapse, ListItemButton } from "@mui/material";
import { ExpandLess, ExpandMore } from "@mui/icons-material";

// define a component that takes an item prop
function CollapsableMenu({ item, subItems, onClick, openId, onAdd, onRemove, onSelected, selectedSubItem }) {
  // create a boolean state to store the open state of the submenu
  const [open, setOpen] = useState(false);

  // define a function to toggle the open state of the submenu
  const handleClick = () => {
    // invert the boolean value
    onClick();
    setOpen(!open);
  };

  const handleSubItemClick = (subItem) => {
    onSelected(subItem);
    console.log('subItem', subItem)
  };

  const handleAdd = () => {
    onAdd();
    console.log('add new appointment')
  }

  const handleRemove = () => {
    onRemove();
    console.log('remove appointment')
  }

  return (
    <div>
      <ListItem key={item}>
        <ListItemButton onClick={handleClick}
            sx={{
                    ...(openId ===item.id && {
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      '& .MuiListItemIcon-root': {
                        color: 'white',
                      },
                      '& .MuiListItemText-root': {
                        color: 'white',
                      },
                    }),
                    '&:not(:disabled):hover': {
                        backgroundColor: 'rgba(255, 255, 255, 0.2)',
                        '& .MuiListItemIcon-root': {
                          color: 'white',
                        },
                        '& .MuiListItemText-root': {
                          color: 'white',
                        },
                      },
                  }}>
            <ListItemText primary={item.name}/>
            {/* show an icon based on the open state */}
            {Array.isArray(subItems) && (open ? <ExpandLess /> : <ExpandMore />)}
        </ListItemButton>
      </ListItem>
      {/* wrap the sub-list items with Collapse component */}
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {Array.isArray(subItems) && 
            subItems.map((subItem) => (
            <ListItem key={subItem.id}>
                <ListItemButton onClick={() => handleSubItemClick(subItem)}
                    sx={{
                        ...(selectedSubItem ===subItem.id && {
                        backgroundColor: 'rgba(255, 255, 255, 0.2)',
                        '& .MuiListItemIcon-root': {
                            color: 'white',
                        },
                        '& .MuiListItemText-root': {
                            color: 'white',
                        },
                        }),
                        '&:not(:disabled):hover': {
                            backgroundColor: 'rgba(255, 255, 255, 0.2)',
                            '& .MuiListItemIcon-root': {
                            color: 'white',
                            },
                            '& .MuiListItemText-root': {
                            color: 'white',
                            },
                        },
                    }}>
                <ListItemText primary={subItem.appointment_date}  
                    primaryTypographyProps={{ sx: { fontSize: "14px", textIndent:'20px'} }}/>
                </ListItemButton>  
            </ListItem>
          ))}
            <ListItem>
                <ListItemButton onClick={handleAdd}>
                    <ListItemText primary="Add New Appointment"  
                        primaryTypographyProps={{ sx: { fontSize: "14px", textIndent:'20px' } }}/>
                </ListItemButton>  
            </ListItem>
            <ListItem>
                <ListItemButton onClick={handleRemove}>
                    <ListItemText primary="Remove Appointment"  
                        primaryTypographyProps={{ sx: { fontSize: "14px", textIndent:'20px' } }}/>
                </ListItemButton>  
            </ListItem>
        </List>
      </Collapse>
    </div>
  );
}

export default CollapsableMenu;