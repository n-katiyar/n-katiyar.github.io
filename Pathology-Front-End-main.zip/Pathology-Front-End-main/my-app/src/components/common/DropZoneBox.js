// import Dropzone from "react-dropzone"
// import * as React from 'react';
import Box from '@mui/material/Box';
// import Button from '@mui/material/Button';

// const DropZoneBox = () => {
//     return (
//         <Box component="span" sx={{ p: 2, border: '1px dashed grey', width: "40%", height: "35%",textAlign: 'center',margin: "auto"}}>
//             <p>Drag or click to upload files</p>
//             <Dropzone onDrop={acceptedFiles => console.log(acceptedFiles)}>
//             {({getRootProps, getInputProps}) => (
//                 <section>
//                 <div {...getRootProps()}>
//                     <input {...getInputProps()} />
                    
//                     <Button variant="contained">Upload</Button>
//                 </div>
//                 </section>
//             )}
//             </Dropzone>
//         </Box>
//     );
// }

// export default DropZoneBox;

import React, {useCallback} from 'react'
import {useDropzone} from 'react-dropzone'

function DropZoneBox({onDrop}) {
    const {acceptedFiles, getRootProps, getInputProps} = useDropzone({onDrop})
    const {ref, ...rootProps} = getRootProps()

    return (
        <Box ref={ref} sx={{ p: 10, border: '1px dashed grey',textAlign: 'center',backgroundColor:'#e3e4e9'}} {...rootProps}>
        <input {...getInputProps()} />
        <p>Drag 'n' drop some files here, or click to select files. </p>
        <p>Only .jpeg, .png images and .zip files will be accepted</p>
        <p>{acceptedFiles.map(file => file.name).join(', ')}</p>
        </Box>
    )
}

export default DropZoneBox
