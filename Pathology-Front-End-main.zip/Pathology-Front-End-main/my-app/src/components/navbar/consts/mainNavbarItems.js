import ImageIcon from '@mui/icons-material/Image';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import LogoutIcon from '@mui/icons-material/Logout';
import HomeIcon from '@mui/icons-material/Home';
import ChatBubbleIcon from '@mui/icons-material/ChatBubble';
export const mainNavbarItems = [
    {
        id: 0,
        icon: <HomeIcon/>,
        label: 'Home',
        route: '/'
    },
    {
        id: 1,
        icon: <ImageIcon/>,
        label: 'Editor',
        route: '/editor'
    },
    {
        id: 2,
        icon: <CloudUploadIcon/>,
        label: 'Upload',
        route: '/upload'
    },
    // {
    //     id: 4,
    //     icon: <ChatBubbleIcon/>,
    //     label: 'Chat',
    //     route: '/chat'
    // },
    {
        id: 3,
        icon: <LogoutIcon/>,
        label: 'Logout',
        route: '/signin'
    },
]