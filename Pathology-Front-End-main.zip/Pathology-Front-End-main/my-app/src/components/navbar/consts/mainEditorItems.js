export const diseases = [
    {
      value: 'ampulla_of_vater_accuracy',
      label: 'Ampulla of Vater',
    },
    {
      value: 'angiectasia_accuracy',
      label: 'Angiectasia',
    },
    {
      value: 'blood_fresh_accuracy',
      label: 'Fresh Blood',
    },
    {
      value: 'blood_hematin_accuracy',
      label: 'Hematin Blood',
    },
    {
        value: 'erosion_accuracy',
        label: 'Erosion',
      },
      {
        value: 'erythema_accuracy',
        label: 'Erythema',
      },
      {
        value: 'foreign_body_accuracy',
        label: 'Foreign Body',
      },
      {
        value: 'ileocecal_valve_accuracy',
        label: 'Ileocecal Valve Body',
      },
      {
        value: 'lymphangiectasia_accuracy',
        label: 'Lymphangiectasia',
      },
      {
        value: 'normal_clean_mucosa_accuracy',
        label: 'Normal',
      },
      {
        value: 'polyp_accuracy',
        label: 'Polyp',
      },
      {
        value: 'pylorus_accuracy',
        label: 'Pylorus',
      },
      {
        value: 'reduced_mucosal_view_accuracy',
        label: 'Reduced Mucosal View',
      },
      {
        value: 'ulcer_accuracy',
        label: 'Ulcer',
      },
      {
        value: '',
        label: 'Unprocessed'
      },
      {
        value: 'other',
        label: 'Other',
      }
  ];