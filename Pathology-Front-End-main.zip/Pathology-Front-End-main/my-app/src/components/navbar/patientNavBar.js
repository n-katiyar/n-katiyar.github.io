import React, { useState, useContext } from 'react';
import Drawer from '@mui/material/Drawer';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import NewPatientPopup from './NewPatientPopup';
import PersonRemoveIcon from '@mui/icons-material/PersonRemove';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import { useEffect } from 'react';
import { api } from '../api';
import ConfirmationDialog from '../common/ConfirmationDialog';
import CollapsableMenu from '../common/CollapsableMenu';
import NewAppointmentPopup from './NewAppointmentPopup';
import UserContext from '../../context/UserContext';

export const newPatient = {
  icon: <PersonAddAlt1Icon/>,
  label: 'Add New Patient',
  color: 'rgba(255,255,255,0.4)',
}

export const removePatient = {
  icon: <PersonRemoveIcon/>,
  label: 'Remove Patient',
  color: 'rgba(255,255,255,0.4)',
}

export const editPatient = {
  icon: <ManageAccountsIcon/>,
  label: 'Edit Patient',
  color: 'rgba(255,255,255,0.4)',
}

const PatientNavbar = () => {
  const [showNewPatientPopup, setShowNewPatientPopup] = useState(false);
  const [showNewAppointmentPopup, setShowNewAppointmentPopup] = useState(false);
  const [patients, setPatients] = useState([]);
  const [showDeletePatientPopup, setDeletePatientPopup] = useState(false);
  const [showDeleteAppointment, setDeleteAppointment] = useState(false);
  const { currentPatient, currentAppointment, currentDoctor, setCurrentPatient, setCurrentAppointment} = useContext(UserContext);
  const [updateBar, setUpdateBar] = useState(false);


  useEffect(() => {
    // Fetch patients by doctor id
    // fetch(api.url + `doctor/${currentDoctor.id}/patients`)
    fetch(api.gateway_url + `patients/${currentDoctor.id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then(data => {
        let body = JSON.parse(data.body)
        // Set patients state variable
        setPatients(body.patients);
  
        // Loop through each patient and fetch their appointments by patient id
        body.patients.forEach(patient => {
          // fetch(api.url + `patient/${patient.id}/appointments`)
          fetch(api.gateway_url + `patients/appointments/${patient.id}`)
            .then(response => {
              if (!response.ok) {
                throw new Error("Network response was not ok");
              }
              return response.json();
            })
            .then(data => {
              let body = JSON.parse(data.body)
              // Add appointments property to patient object
              patient.appointments = body;
  
              // Update patients state variable with modified patient object
              setPatients(prevPatients =>
                prevPatients.map(p =>
                  p.id === patient.id ? { ...p, appointments: body } : p
                )
              );
            })
            .catch(error => {
              console.error("Error fetching appointments:", error);
            });
        });
      })
      .catch(error => {
        console.error("Error fetching patients:", error);
      });
  }, [currentDoctor,updateBar]);

  const handlePatientClick = (patientId) => {
    if (patientId) {
      const patientIndex = patients.findIndex(patient => patient.id === patientId);
      setCurrentPatient(patients[patientIndex]);
      setCurrentAppointment(null);
      console.log("patient clicked: ", patients[patientIndex]);
      }
  };

  const createNewPatient = (patient) => {
    fetch(api.gateway_url+'patients', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: patient.firstName + ' ' + patient.lastName,
        age: patient.age,
        doctor_id: currentDoctor.id,
      })
    })
    .then(response => response.json())
    .then(data => {
      console.log(data)
      let newPatient = {
        id: data.id,
        name: data.name,
        patientId: data.patient_id
      };
      const newPatients = [...patients, newPatient];
      setPatients(newPatients);
    })
    .catch(error => console.error(error));
  };

  const handleCreateNewAppointment = (appointment) => {
    fetch(api.gateway_url+`appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        doctor_id: currentDoctor.id,
        appointment_date: appointment.date,
        patient_id: currentPatient.id
      }),
    })
      .then(response => {
        console.log('response: ', response)
        console.log(response.body)
        if (!response.ok) {
          throw new Error('Failed to create appointment');
        }
        return response.json();
      })
      .then(data => {
        console.log('created appointment: ', data);
        setUpdateBar(!updateBar);
        // const newAppointment = data.appointment;
        // // Append new appointment to current patient object
        // setCurrentPatient(prevPatient => {
        //   return {
        //     ...prevPatient,
        //     appointments: [...prevPatient.appointments, newAppointment]
        //   };
        // });
        // // Update patients array with updated currentPatient
        // setPatients(prevPatients => {
        //   return prevPatients.map(patient => {
        //     if (patient.id === currentPatient.id) {
        //       return {
        //         ...patient,
        //         appointments: [...patient.appointments, newAppointment]
        //       };
        //     } else {
        //       return patient;
        //     }
        //   });
        // })
      })
      .catch(error => {
        console.error(error);
      });
  }


  const handleDeletePatientConfirmed = () => {
    // fetch(api.url+'patient/delete', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify({
    //     patient_id: currentPatient.id,
    //   })
    // })
    fetch(api.gateway_url + `patients/patient/${currentPatient.id}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => {
      if (response.status === 200) {
        const newPatients = patients.filter(patient => patient.id !== currentPatient.id);
        setPatients(newPatients);
        return response.json();
      } else {
        throw new Error('Invalid response status');
      }
    })
    .catch(error => console.error(error));
    console.log("deleting patient with id: " + currentPatient.id);
  }

  const handleDeleteAppointmentConfirmed = () => {
    fetch(api.gateway_url+`appointments/${currentAppointment.id}`, {
      method: 'DELETE'
    })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        if (response.ok){
          // Remove the deleted appointment from currentPatient and patients
          setCurrentPatient(prevPatient => {
            const updatedAppointments = prevPatient.appointments.filter(appointment => appointment.id !== currentAppointment.id);
            return {
              ...prevPatient,
              appointments: updatedAppointments
            };
          });
          setPatients(prevPatients => {
            const updatedPatients = prevPatients.map(patient => {
              if (patient.id === currentPatient.id) {
                const updatedAppointments = patient.appointments.filter(appointment => appointment.id !== currentAppointment.id);
                return {
                  ...patient,
                  appointments: updatedAppointments
                };
              }
              return patient;
            });
            return updatedPatients;
          });
          setCurrentAppointment(null);
        }
        console.log('Appointment deleted successfully');
      })
      .catch(error => {
        console.error('Error deleting appointment:', error);
      });
    console.log("deleting appointment with id: " + currentAppointment.id);
  }

  const handleSelectedAppointment = (appointment) => {
    setCurrentAppointment(appointment);
    console.log("appointment selected: ", appointment)
  }

    const drawerWidth = 240;
    return (
        <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: '#1a1a1a',
            color: 'rgba(255, 255, 255, 0.7)'
          },
        }}
        variant="permanent"
        anchor="right"
      >
        <Toolbar>
        </Toolbar>
        <Divider />
        <List>
          {patients.map((item, index) => (
            <CollapsableMenu item={item} 
            key={item.id}
              subItems={item.appointments} 
              onClick={() => handlePatientClick(item.id)}
              openId={currentPatient? currentPatient.id:false}
              onAdd={() => setShowNewAppointmentPopup(true)}
              onRemove={() => setDeleteAppointment(true)}
              onSelected={handleSelectedAppointment}
              selectedSubItem={currentAppointment?currentAppointment.id:false}/>
          ))}
          <ListItem key={newPatient.label} disablePadding>
            <ListItemButton onClick={() => setShowNewPatientPopup(true)}>
              <ListItemIcon sx={({ color: newPatient.color})}>
                {newPatient.icon}
              </ListItemIcon>
              <ListItemText primary={newPatient.label} />
            </ListItemButton>
          </ListItem>
          <ListItem key={removePatient.label} disablePadding>
            <ListItemButton onClick={() => setDeletePatientPopup(true)}>
              <ListItemIcon sx={({ color: removePatient.color})}>
                {removePatient.icon}
              </ListItemIcon>
              <ListItemText primary={removePatient.label} />
            </ListItemButton>
          </ListItem>
        </List>
        {showNewAppointmentPopup && (
          <NewAppointmentPopup isOpen={showNewAppointmentPopup} onClose={() => setShowNewAppointmentPopup(false)} onCreate={handleCreateNewAppointment}/>
        )}
        {showNewPatientPopup && (
        <NewPatientPopup isOpen={showNewPatientPopup} onClose={() => setShowNewPatientPopup(false)} onCreate={createNewPatient}/>
      )}
      {showDeletePatientPopup && currentPatient && (
        <ConfirmationDialog
          isOpen={showDeletePatientPopup}
          title="Confirm action"
          message={"Are you sure you want to delete " + currentPatient.name + "?"}
          buttonText="Delete"
          onConfirm={handleDeletePatientConfirmed}
          onClose={() => setDeletePatientPopup(false)}
        />
      )}
      {showDeleteAppointment && currentAppointment && currentPatient && (
        <ConfirmationDialog
          isOpen={showDeleteAppointment}
          title="Confirm action"
          message={"Are you sure you want to delete appointment " + currentAppointment.appointment_date + " from " + currentPatient.name + "?"}
          buttonText="Delete"
          onConfirm={handleDeleteAppointmentConfirmed}
          onClose={() => setDeleteAppointment(false)}
        />
      )}
        
      </Drawer>
      
    );
}

export default PatientNavbar;