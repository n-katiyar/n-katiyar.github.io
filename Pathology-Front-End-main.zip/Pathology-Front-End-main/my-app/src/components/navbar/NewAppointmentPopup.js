import { useState } from 'react';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Typography} from '@mui/material';

const NewPatientPopup = ({ isOpen, onClose, onCreate }) => {
  const [date, setDate] = useState('');

  const handleCreate = () => {
    
    const newAppointment = {
      date
    };

    onCreate(newAppointment);
    onClose();
  };

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>Create New Appointment</DialogTitle>
      <DialogContent >
        <TextField label="Appointment Date" value={date} onChange={(e) => setDate(e.target.value)} fullWidth sx={{ mb: 1, mt: 1 }}/>
      </DialogContent>
      <Typography variant='caption' sx={{ ml: 3, mb: 1 }}>Attention: appointments cannot be edited after creation.</Typography>
      <DialogActions sx={{mb:2,ml:5,mr:5, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 16px' }}>
          <Button onClick={onClose}>Cancel</Button>
          <Button onClick={handleCreate}>Create</Button>
    </DialogActions>
    </Dialog>
  );
};
export default NewPatientPopup;