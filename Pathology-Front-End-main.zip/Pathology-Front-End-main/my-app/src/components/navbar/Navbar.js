// import React from 'react';
import * as React from 'react';
import Drawer from '@mui/material/Drawer';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { mainNavbarItems } from './consts/mainNavbarItems';
import { useNavigate } from 'react-router-dom';
import { useLocation} from 'react-router-dom';
import { Auth } from 'aws-amplify';
import UserContext from '../../context/UserContext';
import { useContext } from 'react';


const Navbar = () => {
    const {setCurrentDoctor} = useContext(UserContext);
    const navigate = useNavigate();
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const drawerWidth = 240;

    const handleLogout = () => {
        try {
          Auth.signOut();
          setCurrentDoctor(null);
          console.log('signed out')
      } catch (error) {
          console.log('error signing out: ', error);
      }
      navigate('/signin', { replace: true })
    }

    const handlePageChange = (route,searchParams) => {
      if (route =='/signin') {
        handleLogout();
      } else {
        navigate({pathname:route, search: searchParams.toString() })
      }
      
    }

    return (
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            backgroundColor: '#1a1a1a',
            color: 'rgba(255, 255, 255, 0.7)'
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <Toolbar />
        <Divider />
        <List>
          {mainNavbarItems.map((item, index) => {
            const isSelected = location.pathname === item.route;
            return (
              <ListItem key={item.id} disablePadding>
                <ListItemButton
                  onClick={() => handlePageChange(item.route,searchParams)}
                  sx={{
                    ...(isSelected && {
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      '& .MuiListItemIcon-root': {
                        color: 'white',
                      },
                      '& .MuiListItemText-root': {
                        color: 'white',
                      },
                    }),
                  }}
                >
                  <ListItemIcon sx={({ color: 'rgba(255, 255, 255, 0.7)'})}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText primary={item.label} />
                </ListItemButton>
              </ListItem>
            );
          })}
        </List>
      </Drawer>
    );
}

export default Navbar;