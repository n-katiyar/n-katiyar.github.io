import { useState } from 'react';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Typography} from '@mui/material';

const NewPatientPopup = ({ isOpen, onClose, onCreate }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [age, setAge] = useState('');

  const handleCreate = () => {
    
    const newPatient = {
      firstName,
      lastName,
      age,
    };

    onCreate(newPatient);
    onClose();
  };

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>Create New Patient</DialogTitle>
      <DialogContent >
        <TextField label="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} fullWidth sx={{ mb: 1, mt: 1 }}/>
        <TextField label="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} fullWidth  sx={{ mb: 1 }}/>
        <TextField label="Age" value={age} onChange={(e) => setAge(e.target.value)} fullWidth />
      </DialogContent>
      <Typography variant='caption' sx={{ ml: 3, mb: 1 }}>Attention: patients cannot be edited after creation.</Typography>
      <DialogActions sx={{mb:2,ml:5,mr:5, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 16px' }}>
          <Button onClick={onClose}>Cancel</Button>
          <Button onClick={handleCreate}>Create</Button>
    </DialogActions>
    </Dialog>
  );
};
export default NewPatientPopup;