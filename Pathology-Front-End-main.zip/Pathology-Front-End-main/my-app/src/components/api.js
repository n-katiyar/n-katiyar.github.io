export const api = {
    // url: 'http://127.0.0.1:5000/',
    url:'http://15.222.118.244:80/',
    upload_image: 'upload_image',
    get_image: 'get-image',
    get_images: 'get-images',
    localurl: 'http://localhost:3000/',
    gateway_url: 'https://ulpawdzp8e.execute-api.ca-central-1.amazonaws.com/test/'
}