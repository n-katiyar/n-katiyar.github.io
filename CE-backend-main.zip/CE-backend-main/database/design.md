# Database design

## Tables

| Table Name   | Description                    |
|--------------|--------------------------------|
| doctors    | Stores doctor information    |
| patients       | Tracks customer orders         |
| appointments | Tracks appointments between doctors and patients |
| hospitals | stores hospitals information |
| images | stores images information |
| diagnoses| stores diagnoses information |

## Tables Relationship

| Table Name   | Foreign Key   | Referenced Table |
|--------------|---------------|------------------|
| doctors       | hospital_id   | hospitals        |
| patients   | doctor_id    | doctors         |
| appointments    | patient_id, doctor_id    | patients,doctors        |
| images    | appointment_id, diagnoses_id, ai_diagnosis_id    | appointments, diagnoses       |

## Tables Information
### Hospitals
| id   | name   |
|------|--------|
| integer    | string |
### Doctors
| id   | name   | hospital_id |
|------|--------|-------------|
| integer    | string| integer_reference           |
### Patients
| id   | name   | doctor_id |
|------|--------|-------------|
| integer    | string| integer_reference           |
### Appointments
| id   | patient_id   | doctor_id | appointment_date |
|------|--------|-------------|-------------|
| integer    | integer_reference| integer_reference| date|
### Images
| id   | appointment_id   | diagnoses_id | image_name | processed | modified | modified_diagnosis_id | ai_diagnosis_id |
|------|--------|-------------|-------------|------------|--|--|--|
| integer    | integer_reference| integer_reference| string| boolean| boolean (default false) | integer | integer_reference |
### Diagnoses
| id   |  ampulla_of_vater_accuracy  | angiectasia_accuracy| blood_fresh_accuracy|blood_hematin_accuracy|erosion_accuracy|erythema_accuracy|foreign_body_accuracy|ileocecal_valve_accuracy|lymphangiectasia_accuracy|normal_clean_mucosa_accuracy|polyp_accuracy|pylorus_accuracy|reduced_mucosal_view_accuracy|ulcer_accuracy|
|------|--------|--|--|--|--|--|--|--|--|--|--|--|--|--|
| integer    | float (not null, default 0)| " | " | " | " | " | " | " | " | " | " | " | " | " | " |


