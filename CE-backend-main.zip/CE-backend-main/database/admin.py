import psycopg2

# Set the connection parameters
host = '172.31.9.59'
port = '5432'  # default PostgreSQL port
dbname = 'dev_database'
user = 'dev'
password = 'Capma1!'

# Connect to the database
try:
    conn = psycopg2.connect(
        host=host,
        port=port,
        dbname=dbname,
        user=user,
        password=password
    )
except psycopg2.Error as e:
    print('Unable to connect to the database: {}'.format(e))
    exit(1)

# Define the image ID that you want to delete
image_id = 1

# Create a cursor object
cur = conn.cursor()

try:
    # Create an hospital
    cur.execute("INSERT INTO hospitals (name) VALUES (%s)", ('default hospital',))
    # Execute the query
    cur.execute("INSERT INTO doctors (name, hospital_id) VALUES (%s, %s)", ('Alice Doe', 1))

    # Commit the changes to the database
    conn.commit()

    print("Inserted successfully")

except Exception as e:
    # Rollback the changes if there was an error
    conn.rollback()
    print("Error :", e)

finally:
    # Close the cursor and connection objects
    cur.close()
    conn.close()