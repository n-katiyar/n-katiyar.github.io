import psycopg2
import json
# open json file with credentials
with open('/home/ec2-user/pathology-detection/backend/app/credentials/creds.json','r') as f:
    creds = json.load(f)

# Set the connection parameters
host = creds['endpoint']
port = '5432'  # default PostgreSQL port
dbname = 'your-db-name-here'
user = creds['username']
password = creds['password']

# Connect to the database
try:
    conn = psycopg2.connect(
        host=host,
        port=port,
        # dbname=dbname,
        user=user,
        password=password
    )
except psycopg2.Error as e:
    print('Unable to connect to the database: {}'.format(e))
    exit(1)

# Open a cursor to perform database operations
cur = conn.cursor()


# Query the system catalog tables to retrieve information about the database objects
cur.execute("""
    SELECT table_name, column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'public'
    ORDER BY table_name, ordinal_position
""")

# Fetch all the records and print them to the console
records = cur.fetchall()
current_table = None
for record in records:
    table_name, column_name, data_type = record
    if table_name != current_table:
        current_table = table_name
        print(f"Table: {current_table}")
    print(f"  Column: {column_name}, Type: {data_type}")
# Close the cursor and connection
cur.close()
# Open a cursor to perform database operations
cur = conn.cursor()
# Retrieve foreign key constraints
cur.execute("""
    SELECT conname, conrelid::regclass, confrelid::regclass
    FROM pg_constraint
    WHERE contype = 'f'
""")

# Fetch all rows
rows = cur.fetchall()

# Print the relationships
for row in rows:
    print(f"{row[1]} references {row[2]} via {row[0]}")


# Close the cursor and connection
cur.close()
conn.close()
