from ..database import db
import boto3
import os
import json
# credentials_dir = os.path.join(os.path.dirname(__file__), 'credentials')
# # Get the path to the file within the credentials directory
# file_path = os.path.join(credentials_dir, 's3_creds.json')   
# with open('/home/ec2-user/pathology-detection/backend/app/models/s3_creds.json','r') as f:
#     creds = json.load(f)
creds = {
    'AWS_ACCESS_KEY_ID': os.environ.get('AWS_ACCESS_KEY_ID'),
    'AWS_SECRET_ACCESS_KEY': os.environ.get('AWS_SECRET_ACCESS_KEY'),
    'AWS_REGION': 'ca-central-1'
}
# s3 = boto3.client('s3',
#                   aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],
#                   aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],
#                   region_name=creds['AWS_REGION'])

class Appointment(db.Model):
    __tablename__ = 'appointments'
    id = db.Column(db.Integer, primary_key=True)
    appointment_date = db.Column(db.Date)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'))

    def to_dict(self):
        return {
            'id': self.id,
            'appointment_date': str(self.appointment_date),
            'patient_id': self.patient_id,
            'doctor_id': self.doctor_id
        }

class Patient(db.Model):
    __tablename__ = 'patients'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    age = db.Column(db.Integer)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'))
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'age': self.age,
            'doctor_id': self.doctor_id
        }

class Hospital(db.Model):
    __tablename__ = 'hospitals'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name
        }

class Doctor(db.Model):
    __tablename__ = 'doctors'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitals.id'), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'hospital_id': self.hospital_id
        }

class Diagnosis(db.Model):
    __tablename__ = 'diagnoses'
    id = db.Column(db.Integer, primary_key=True)
    ampulla_of_vater_accuracy = db.Column(db.Float)
    angiectasia_accuracy = db.Column(db.Float)
    blood_fresh_accuracy = db.Column(db.Float)
    blood_hematin_accuracy = db.Column(db.Float)
    erosion_accuracy = db.Column(db.Float)
    erythema_accuracy = db.Column(db.Float)
    foreign_body_accuracy = db.Column(db.Float)
    ileocecal_valve_accuracy = db.Column(db.Float)
    lymphangiectasia_accuracy = db.Column(db.Float)
    normal_clean_mucosa_accuracy = db.Column(db.Float)
    polyp_accuracy = db.Column(db.Float)
    pylorus_accuracy = db.Column(db.Float)
    reduced_mucosal_view_accuracy = db.Column(db.Float)
    ulcer_accuracy = db.Column(db.Float)
    other = db.Column(db.String, default=None)

    def __init__(self):
        self.ampulla_of_vater_accuracy = 0
        self.angiectasia_accuracy = 0
        self.blood_fresh_accuracy = 0
        self.blood_hematin_accuracy = 0
        self.erosion_accuracy = 0
        self.erythema_accuracy = 0
        self.foreign_body_accuracy = 0
        self.ileocecal_valve_accuracy = 0
        self.lymphangiectasia_accuracy = 0
        self.normal_clean_mucosa_accuracy = 0
        self.polyp_accuracy = 0
        self.pylorus_accuracy = 0
        self.reduced_mucosal_view_accuracy = 0
        self.ulcer_accuracy = 0
        self.other= None
    
    def to_dict(self):
        diagnoses_dict = {
            'ampulla_of_vater_accuracy': self.ampulla_of_vater_accuracy,
            'angiectasia_accuracy': self.angiectasia_accuracy,
            'blood_fresh_accuracy': self.blood_fresh_accuracy,
            'blood_hematin_accuracy': self.blood_hematin_accuracy,
            'erosion_accuracy': self.erosion_accuracy,
            'erythema_accuracy': self.erythema_accuracy,
            'foreign_body_accuracy': self.foreign_body_accuracy,
            'ileocecal_valve_accuracy': self.ileocecal_valve_accuracy,
            'lymphangiectasia_accuracy': self.lymphangiectasia_accuracy,
            'normal_clean_mucosa_accuracy': self.normal_clean_mucosa_accuracy,
            'polyp_accuracy': self.polyp_accuracy,
            'pylorus_accuracy': self.pylorus_accuracy,
            'reduced_mucosal_view_accuracy': self.reduced_mucosal_view_accuracy,
            'ulcer_accuracy': self.ulcer_accuracy,
        }
        max_diagnosis = max(diagnoses_dict, key=diagnoses_dict.get)
        if (self.other != 'None'):
            diagnoses_dict['max_diagnosis'] = {'name':max_diagnosis, 'accuracy':diagnoses_dict[max_diagnosis]}
        else:
            diagnoses_dict['max_diagnosis'] = {'name':self.other, 'accuracy':1}
            
        diagnoses_dict['other'] = self.other
        return diagnoses_dict


class Image(db.Model):
    __tablename__ = 'images'
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'))
    image_name = db.Column(db.String)
    processed = db.Column(db.Boolean)
    modified = db.Column(db.Boolean) 
    time = db.Column(db.Integer) # timestamp inside video
    modified_diagnosis_id = db.Column(db.Integer, db.ForeignKey('diagnoses.id'))
    ai_diagnosis_id = db.Column(db.Integer, db.ForeignKey('diagnoses.id'))

    def to_dict(self):
        s3 = boto3.client('s3',
                  aws_access_key_id=creds['AWS_ACCESS_KEY_ID'],
                  aws_secret_access_key=creds['AWS_SECRET_ACCESS_KEY'],
                  region_name=creds['AWS_REGION'])
        image_url = s3.generate_presigned_url('get_object', Params={'Bucket': 'capm-ai', 'Key': self.image_name})

        # Retrieve the diagnosis object
        modified_diagnosis = Diagnosis.query.filter_by(id=self.modified_diagnosis_id).first()
        ai_diagnosis = Diagnosis.query.filter_by(id=self.ai_diagnosis_id).first()

        return {
            'id': self.id,
            'appointment_id': self.appointment_id,
            'image_name': self.image_name,
            'processed': self.processed,
            'modified': self.modified,
            'modified_diagnosis_id': self.modified_diagnosis_id,
            'ai_diagnosis_id': self.ai_diagnosis_id,
            'image_url': image_url,
            'modified_diagnosis': modified_diagnosis.to_dict() if modified_diagnosis else None,
            'ai_diagnosis': ai_diagnosis.to_dict() if ai_diagnosis else None
        }