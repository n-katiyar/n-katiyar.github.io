from flask import jsonify, Blueprint
from app.models.models import Hospital
from app.database import db

bp = Blueprint('hospitals', __name__)

@bp.route('/hospitals', methods=['GET'])
def get_hospitals():
    try:
        hospitals = Hospital.query.all()
        return jsonify([hospital.to_dict() for hospital in hospitals]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
