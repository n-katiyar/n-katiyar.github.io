from flask import request, jsonify, Blueprint
from datetime import datetime
from ..models.models import Hospital, Doctor, Image, Appointment, Patient
from ..database import db

bp = Blueprint('api', __name__)

@bp.route('/api/doctor/create', methods=['POST'])
def create_doctor():
    name = request.json['name']
    hospital_id = request.json['hospital_id']

    hospital = Hospital.query.get(hospital_id)
    if not hospital:
        return jsonify({'message': 'Hospital not found.'}), 404

    doctor = Doctor(name=name, hospital_id=hospital_id)
    db.session.add(doctor)
    db.session.commit()

    return jsonify({'id': doctor.id, 'name': doctor.name, 'hospital_id': doctor.hospital_id}), 201

@bp.route('/api/hospital/create', methods=['POST'])
def create_hospital():
    name = request.json.get('name')
    if not name:
        return jsonify({'error': 'Missing parameter: name'}), 400

    hospital = Hospital(name=name)
    db.session.add(hospital)
    db.session.commit()

    return jsonify({'id': hospital.id, 'name': hospital.name}), 201

@bp.route('/api/appointment/create', methods=['POST'])
def create_appointment():
    data = request.json
    appointment_date = datetime.strptime(data['appointment_date'], '%Y-%m-%d').date()
    patient_id = data['patient_id']
    doctor_id = data['doctor_id']
    appointment = Appointment(appointment_date=appointment_date, patient_id=patient_id, doctor_id=doctor_id)
    db.session.add(appointment)
    db.session.commit()
    return jsonify({'message': 'Appointment created successfully.'}), 201


