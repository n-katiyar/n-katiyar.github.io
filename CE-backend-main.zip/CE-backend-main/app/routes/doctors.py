from flask import Blueprint, jsonify, request, abort
from ..database import db
from app.models.models import Doctor

bp = Blueprint('doctors', __name__)

@bp.route('/doctor/<int:doctor_id>', methods=['GET'])
def get_doctor(doctor_id):
    try:
        doctor = Doctor.query.get(doctor_id)
        if doctor is None:
            return jsonify({'error': 'Doctor not found'}), 404
        
        response = doctor.to_dict()
        return jsonify(response), 200
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.session.close()