from flask import Flask
import json
from .database import db
from .routes import api
from .routes import patients
from .routes import hospitals
from .routes import appointments
from .routes import doctors
from .routes import images
from .routes import diagnosis
import os
from flask_cors import CORS

def create_app():
    # open json file with credentials
    # Get the path to the credentials directory
    # credentials_dir = os.path.join(os.path.dirname(__file__), 'credentials')
    # Get the path to the file within the credentials directory
    # file_path = os.path.join(credentials_dir, 'creds.json')   
    # with open(file_path,'r') as f:
    #     creds = json.load(f)

    # Set the connection parameters
    # host = 	'35.183.119.42'
    # user = 'dev'
    # password = 'Capma1!'
    app = Flask(__name__)
    CORS(app)
    # CORS(app, resources={r"/*": {"origins": ["http://localhost:3000"]}})
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://dev:Capma1!@172.31.9.59:5432/dev_database'
    db.init_app(app)  # move the import of db instance here
    app.register_blueprint(api.bp)
    app.register_blueprint(patients.bp)
    app.register_blueprint(hospitals.bp)
    app.register_blueprint(appointments.bp)
    app.register_blueprint(doctors.bp)
    app.register_blueprint(images.bp)
    app.register_blueprint(diagnosis.bp)
    return app