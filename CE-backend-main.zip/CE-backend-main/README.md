# CE-backend

## Usage
NOTE: requires python 3.8 or higher \
NOTE: sudo is required to give flask access to port 80 

On ubuntu, install the following packages using apt-get: \
`sudo apt-get install python3.8-dev libpq-dev libjpeg-dev zlib1g-dev postgresql postgresql-contrib`

Install dependencies using \
`sudo pip install -r requirements.txt` 

Start the server using \
`sudo -E python run.py` 
-E is required to keep the environment variables, such as AWS credentials

## Database setup
### Install postgresql 
`sudo apt-get install postgresql postgresql-contrib` 

### Set up remote access 
`sudo nano /etc/postgresql/12/main/postgresql.conf` \
change `listen_addresses = 'localhost'` to `listen_addresses = '*'` \
`sudo nano /etc/postgresql/12/main/pg_hba.conf` \
add change ip to 0.0.0.0/0 in the ipv4 section 

### Create user and database
First connect to postgres as the default user postgres \
`sudo -u postgres psql` \
Create a database \
`CREATE DATABASE dev_database;` \
Then create a user\
`CREATE USER dev WITH PASSWORD 'password'`;\
and grant privileges (optional)\
`ALTER USER dev CREATEDB;`\

### Create database architecture
use the create_db.py script to create the database architecture 

### Test connection
To test the connection to the database, run \
to test reachability: `pg_isready -h <ip>` \
to test authentication: `psql -h <ip> -U dev -d dev_database` 